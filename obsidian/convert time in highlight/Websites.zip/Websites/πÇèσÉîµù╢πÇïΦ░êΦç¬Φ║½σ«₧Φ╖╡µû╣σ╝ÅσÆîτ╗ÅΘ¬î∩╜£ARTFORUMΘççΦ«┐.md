---
doc_type: hypothesis-highlights
url: >-
  https://mp.weixin.qq.com/s/vxK2nDebBqfneMya9_Hc8w?utm_campaign=%E5%90%8C%E6%97%B6&utm_medium=email&utm_source=Revue+newsletter
date created: 2022-09-13
date modified: 2023-08-22
---

# 《同时》谈自身实践方式和经验｜ARTFORUM采访

## Metadata
- Author: [mp.weixin.qq.com]()
- Title: 《同时》谈自身实践方式和经验｜ARTFORUM采访
- Reference: https://mp.weixin.qq.com/s/vxK2nDebBqfneMya9_Hc8w?utm_campaign=%E5%90%8C%E6%97%B6&utm_medium=email&utm_source=Revue+newsletter
- Category: #article

## Page Notes
## Highlights
- 我对《同时》工作的观察始于其2021年“支持巴勒斯坦”的倡议，虽然无法无条件地认同这个口号，但这一轮积极的活动和报道引发了我进一步了解该区域历史甚至是宗教的兴趣。而从伴随着古巴事件、塔利班掌权、俄乌战争等事件而来的一系列内容生产中可以看出，这个类似通讯社的组织有着自己明确的议程和灵活的工作形态，当然，也在当下的舆论环境中承担了相应的风险。《同时》并未将自身定义为当代艺术实践，但在当代艺术脉络下，他们的工作让我看到了一种人群交织的“新”。 — [Updated on 2022-09-12 18:18:26](https://hyp.is/h8H9GDK2Ee2eBP8fdZXEVQ/mp.weixin.qq.com/s/vxK2nDebBqfneMya9_Hc8w?utm_campaign=%E5%90%8C%E6%97%B6&utm_medium=email&utm_source=Revue+newsletter) — Group: #inbox
- 《同时》的工作是关于抵抗的自我教育，在普遍的撕裂和无助情绪中，是大家努力保持联结的组织尝试。近些年发生在这片土地上的很多事情，让我们越来越意识到在不同群体之间建立共情和通感可以是一种抵抗。 — [Updated on 2022-09-12 18:18:34](https://hyp.is/jNc4QDK2Ee2Zustpfc5ZvQ/mp.weixin.qq.com/s/vxK2nDebBqfneMya9_Hc8w?utm_campaign=%E5%90%8C%E6%97%B6&utm_medium=email&utm_source=Revue+newsletter) — Group: #inbox
- 作为一个传递信息与观点的平台，我们觉得有必要守住一种朝向公共空间的问题意识，并在其中练习对话和协商的能力，因为我们正目睹公共性的坍塌，出于与不可抗力遭遇后的创伤反应或自我合理化。同样重要的是，我们希望累积起某种国际主义网络，从其他地方的抵抗中学习，不要消沉对现实的政治想象力 — [Updated on 2022-09-12 18:19:39](https://hyp.is/s53vUDK2Ee2K6uevgNeR0w/mp.weixin.qq.com/s/vxK2nDebBqfneMya9_Hc8w?utm_campaign=%E5%90%8C%E6%97%B6&utm_medium=email&utm_source=Revue+newsletter) — Group: #inbox
- 有的实践者对《同时》的国际主义表示过不解，觉得“国内”有这么多的事件和议题，为什么还要对“国外”分配注意力？甚至有些本地实践者质疑这种情感是否虚假。理解远方的苦难是否需要以本地的问题意识作为投射才有具身性？对此，我们认为民族国家的治理结构本身就在取消不同群体间体会彼此处境的能力，因而共情的建立本身就具有抵抗性；此外，我们还意识到，所谓西方学者／活动家的目光往往更容易具有世界性，而非西方国家的学者／活动家则被分配了一种视阈范畴，即自身所处的场域，这本身也是一种殖民结构的结果。编委成员各有自己的知识背景和实践路径，都觉得需要不局限于一时一地、以结构性视野来理解发生着什么，而通过关注更广泛的“他者”，也探寻自身在不同权力结构中的位置。 — [Updated on 2022-09-12 18:19:57](https://hyp.is/vidmXjK2Ee2RTN9e4Ig9Lg/mp.weixin.qq.com/s/vxK2nDebBqfneMya9_Hc8w?utm_campaign=%E5%90%8C%E6%97%B6&utm_medium=email&utm_source=Revue+newsletter) — Group: #inbox

