---
url: https://m.douban.com/note/842872393/
readlater:
  id: "1573430684"
  provider: instapaper
  synchtime: 1701965977396
---
 

[登录/注册](https://accounts.douban.com/passport/login?source=main)

[下载豆瓣客户端](https://www.douban.com/doubanapp/app?channel=top-nav)

[豆瓣 6.0 全新发布](https://www.douban.com/doubanapp/app?channel=qipao) [×](javascript: void 0;)

豆瓣

扫码直接下载

[iPhone](https://www.douban.com/doubanapp/redirect?channel=top-nav&direct_dl=1&download=iOS) · [Android](https://www.douban.com/doubanapp/redirect?channel=top-nav&direct_dl=1&download=Android)

- [豆瓣](https://www.douban.com)
- [读书](https://book.douban.com)
- [电影](https://movie.douban.com)
- [音乐](https://music.douban.com)
- [同城](https://www.douban.com/location)
- [小组](https://www.douban.com/group)
- [阅读](https://read.douban.com/?dcs=top-nav&dcm=douban)
- [FM](https://fm.douban.com/?from_=shire_top_nav)
- [时间](https://time.douban.com/?dt_time_source=douban-web_top_nav)
- [豆品](https://market.douban.com/?utm_campaign=douban_top_nav&utm_source=douban&utm_medium=pc_web)

 

[豆瓣社区](https://www.douban.com)

搜索： 搜索你感兴趣的内容和人...

 

- [首页](https://www.douban.com)
- [浏览发现](https://www.douban.com/explore)
- [话题广场 ![new](https://img3.doubanio.com/f/shire/e49eca1517424a941871a2667a8957fd6c72d632/pics/new_menu.gif)](https://www.douban.com/gallery) 

 

[快速注册](https://www.douban.com/accounts/register)

# Media and Science and Technology Studies书籍（2022推荐）

[![Koren](https://img1.doubanio.com/icon/u52579711-39.jpg)](https://www.douban.com/people/korening/) [Koren](https://www.douban.com/people/korening/) 2022-12-27 17:33:58 加拿大

Tung-Hui Hu, Digital Lethargy: Dispatches from an Age of Disconnection

[https://book.douban.com/subject/35720522/](https://book.douban.com/subject/35720522/)

在反抗和发声的叙事逐渐进入主流的资本主义时代，做“主体”，成为“自我”带来了新的绩效要求；另一方面，并不是所有人都能如西方白人一样，获得积极政治主体的地位。在数字资本和平台经济的裹挟中，很多工作者无法也不愿成为完全的自我。数字倦怠（digital lethargy）指的不是放弃反抗，也不是政治宣言，而是一种未发的政治可能性，它让我们能够反思一路向前的线性高效率技术时间，反思何为承受和接受（而非主动），何为坚持和共存。作者言称试图模仿英语系博士论文的写作方法，取材也较多来自艺术作品而非直接的历史社会数据，所以在论证方面可能会给人略有薄弱、飘忽之感。

Hito Steyerl, Duty Free Art: Art in the Age of Planetary Civil War

[https://book.douban.com/subject/26996322/](https://book.douban.com/subject/26996322/)

在社会进入数字化的时代，数字艺术符号更容易成为空置的无意义抽象，随着艺术符号的显见和实体社会的隐形，一系列新的政治问题出现。如何考察艺术品背后的全球利益关系，如何理解算法操控造成的财富不平等，如何理解俗常化的数字文化死角，那些数据图像、垃圾信息、程序享乐和民粹？Steyerl用一种新解法兰克福学派和批判理论的方式，来介入全球被数字符号支配的不平等现象。

Denise Ferreira da Silva, Unpayable Debt

[https://book.douban.com/subject/35809483/](https://book.douban.com/subject/35809483/)

看了独篇，还没看全书版本。西方资本政治制度对受压迫者存在着双重构陷，资本主义价值理论和维护个人权益的政治主体，都根本倚赖于先于资本的奴隶制肉身暴力，和无偿的劳动价值摄取，然后价值才得以被注册进可公约的市场体系。马克思的资本主义理论不是人类社会历史的根本运作机制，而是在暴力制度之上的一种演绎理论。除去不可知的前价值计算，现代社会还精心构造了一套法律伦理体系来捍卫价值/政治主体的合法性。在得偿对等之外，我们还需要从整个律法伦理方面来思考解放的可能路径。

Wendy Hui Kyong Chun, Discriminating Data: Correlation, Neighborhoods, and the New Politics of Recognition

[https://book.douban.com/subject/35522964/](https://book.douban.com/subject/35522964/)

现代技术合流于数据网络理论，所有试图认识人类社会、“解决”社会问题的科学理论，都把人当作可归类、可优化的数据，而这些数据的历史实践是建立在一套歧视假设之上的：种族天然需要隔离、人们只喜欢与“同类”接近，人类必须且可以被“优化”，人的未来行为取决于他们的历史模式，人是统计意义上的人，等等。在这些假设的指导下，现代技术特别是数字网络社群，越来越向着孤立、受控和偏见放大的方向发展。另一方面，随着二战后一系列追求解放的社会运动的发展，挑战主流、宣扬自我（身份）已经成为新的主流政治意识，但同时，什么是自我、如何保持自我且与他者共存，是未被解决的问题。对立的、革命的政治态度是否真的可以促进社会平等，我们又如何与数据技术共存并妥善利用它来塑造新的主体？作者最后留下的几点畅想值得深思。

Lauren Berlant, On the Inconvenience of Other People

[https://book.douban.com/subject/35654054/](https://book.douban.com/subject/35654054/)

人类社群的根本存在方式不是理性规约，而是作为经验性情感（affect）主体或集群互相影响，在关系中共生。人皆存在与他人互侵、不便于他人的欲望，我们都会被作为对象吸收，也只能通过对象化/物化他人的方式来感知吸收他人。社会关系中的侵害和不平等，是这种精神分析本质的一系列演绎。我们因此感到苦闷、耻辱、压抑，或者给别人带去类似干扰，尤其对于社会弱势群体或关系中的弱者而言，不便是一种常态，“接受”才是日常生活的本质，没有这之外的社会，也没有逃避之法。将社会和社群视为情感性社会，才能找到改写社会关系的可能性。

Ed. Geoffrey C. Bowker, Stefan Timmermans, Adele E. Clarke, Ellen Balka, Boundary Objects and Beyond: Working with Leigh Star

[https://book.douban.com/subject/27121690/](https://book.douban.com/subject/27121690/)

Susan Leign Star去世后，Star的同事和合作者为纪念她而编纂的合集。Star的研究主要集中于信息社会、基础设施、科技民族志等领域，她的同事们试图从各个角度来延续这些研究，并把女性主义和酷儿理论结合到科技与研究中。科学概念是如何在社会建构中产生的，它能否被迁移，如何得到迁移，而研究者又应该如何把握和叙述这些过程，这些问题需要boundary objects这个概念的指导。边缘对象（们）允许社群们以自己不同的知识型和实践，来商榷看似一样或类似的科学技术，允许以生态、动态、去权威、去中心和处在关系中的方式来看待科学实践，而民族志和社会学者的任务就是尽可能还原这些多元现实。

Michelle Murphy, Sick Building Syndrome and the Problem of Uncertainty: Environmental Politics, Technoscience, and Women Workers

[https://book.douban.com/subject/2863223/](https://book.douban.com/subject/2863223/)

“病楼症”很难作为一种独立的疾病被概括，但它的症状和影响却是显然普遍的。本书致力于考察病楼症产生的科技史。工业革命创造了机器效率的同时，也改变了人们的工种分配和工作环境设计。现代化办公楼是一系列厂房配置的翻版。二战后的实验室科学，被引入“改良”工作环境的实验：如何在最小的可控空间安排最多劳工，使其发挥最大效益。这一时期，对人的密闭空间实验更侧重于环境变量（温度、湿度）对人的生理学影响；基于此，中央空调系统办公楼被设计出来。历史中，女性更长时间地从事高密度的办公楼机械劳动，另一方面，她们又被天然认为是过于敏感、不可靠的，对自己的感觉不确定的。办公楼中女性的生理症状和暴露在某些化学物质中的危险并没有被认真对待，但历史中，她们的感官知识，却又是认识这现代办公楼密闭病症的唯一来源。

[读书](https://www.douban.com/channel/30168716) [社会学](https://www.douban.com/channel/30168946) [科技史](https://www.douban.com/note/tags/%E7%A7%91%E6%8A%80%E5%8F%B2?people=korening&all=1) [媒介](https://www.douban.com/note/tags/%E5%AA%92%E4%BB%8B?people=korening&all=1) [数字资本](https://www.douban.com/note/tags/%E6%95%B0%E5%AD%97%E8%B5%84%E6%9C%AC?people=korening&all=1)

© 本文版权归 [Koren](https://www.douban.com/people/korening/) 所有，任何形式转载请联系作者。

© [了解版权计划](https://help.douban.com/diary?app=main#t2-qs)

 

 

[赞](https://www.douban.com/accounts/register?reason=like)

 

[转发 27](https://www.douban.com/accounts/register?reason=collect)

微信扫码

- 新浪微博
- QQ好友
- QQ空间

[回应](https://www.douban.com/note/842872393/#sep) [转发](https://www.douban.com/note/842872393/?type=rec#sep) [赞](https://www.douban.com/note/842872393/?type=like#sep) [收藏](https://www.douban.com/note/842872393/?type=collect#sep)

   

[![Koren](https://img1.doubanio.com/icon/up52579711-39.jpg)](https://www.douban.com/people/korening/)

[Koren](https://www.douban.com/people/korening/) (Monaco)

Histories of artificial intelligence Linguistic models and behavior...

## Koren的最新日记  · · · · · ·  ( [全部](https://www.douban.com/people/korening/notes) )

- [Klára (Klari) Dán Von Neumann](https://www.douban.com/note/853553476/ "Klára (Klari) Dán Von Neumann")  (1人喜欢)

## 热门话题  · · · · · ·  ( [去话题广场](/gallery/) )

- [盘点一些神级真唱现场](https://www.douban.com/gallery/topic/3616611/?from=hot_topic_note) 热议 3.9万次浏览
- [冬日里的烟火气](https://www.douban.com/gallery/topic/3614792/?from=hot_topic_note) 4034次浏览
- [每年冬天都会看的剧](https://www.douban.com/gallery/topic/3618704/?from=hot_topic_note) 新话题
- [不考虑薪资你最想从事什么工作？](https://www.douban.com/gallery/topic/3618703/?from=hot_topic_note) 新话题
- [我的冬日小确幸](https://www.douban.com/gallery/topic/3612974/?from=hot_topic_note) 51.2万次浏览
- [大学里那些有趣的选修课](https://www.douban.com/gallery/topic/3618662/?from=hot_topic_note) 新话题

© 2005－2023 douban.com, all rights reserved 北京豆网科技有限公司 [](https://www.douban.com/hnypt/variformcyst.py)[关于豆瓣](https://www.douban.com/about) · [在豆瓣工作](https://www.douban.com/jobs) · [联系我们](https://www.douban.com/about?topic=contactus) · [法律声明](https://www.douban.com/about/legal) · [帮助中心](https://help.douban.com/?app=main) · [移动应用](https://www.douban.com/doubanapp/) · [豆瓣广告](https://www.douban.com/partner/)