---
doc_type: hypothesis-highlights
url: 'https://thenewinquiry.com/not-feeling-it/#annotations:xNgiiCpJEe2JfdtiZtQSlw'
---

# Not Feeling It – The New Inquiry

## Metadata
- Author: [thenewinquiry.com]()
- Title: Not Feeling It – The New Inquiry
- Reference: https://thenewinquiry.com/not-feeling-it/#annotations:xNgiiCpJEe2JfdtiZtQSlw
- Category: #article

## Page Notes
## Highlights
- Yao, much like Lauren Berlant, shows how sentimentality was used for nation-building — [Updated on 2022-09-02 01:11:35](https://hyp.is/bKlhkipLEe2TaYsNU5jJaQ/thenewinquiry.com/not-feeling-it/#annotations:xNgiiCpJEe2JfdtiZtQSlw) — Group: #inbox

- Yao theorizesunfeeling as modes of disaffection and dissent that emerge from different entanglements of biopolitical difference. If feeling is implicitly for white people and only taken as valid in accordance with power, can a case for racialized unfeeling be made? — [Updated on 2022-09-02 01:12:35](https://hyp.is/kGltAipLEe2qTHdtPiA41A/thenewinquiry.com/not-feeling-it/#annotations:xNgiiCpJEe2JfdtiZtQSlw) — Group: #inbox




