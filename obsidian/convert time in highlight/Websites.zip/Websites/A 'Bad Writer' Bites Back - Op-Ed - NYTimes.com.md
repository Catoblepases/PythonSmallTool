---
doc_type: website
url: 
date created: 
date modified: 
---
[A 'Bad Writer' Bites Back - Op-Ed - NYTimes.com](https://archive.nytimes.com/query.nytimes.com/gst/fullpage-950CE5D61531F933A15750C0A96F958260.html)
In the last few years, a small, culturally conservative academic journal has gained public attention by showcasing difficult sentences written by intellectuals in the academy. The journal, Philosophy and Literature, has offered itself as the arbiter of good prose and accused some of us of bad writing by awarding us ''prizes.'' (I'm still waiting for my check!)

The targets, however, have been restricted to scholars on the left whose work focuses on topics like sexuality, race, nationalism and the workings of capitalism -- a point the news media ignored. Still, the whole exercise hints at a serious question about the relation of language and politics: why are some of the most trenchant social criticisms often expressed through difficult and demanding language?

No doubt, scholars in the humanities should be able to clarify how their work informs and illuminates everyday life. Equally, however, such scholars are obliged to question common sense, interrogate its tacit presumptions and provoke new ways of looking at a familiar world.

Many quite nefarious ideologies pass for common sense. For decades of American history, it was ''common sense'' in some quarters for white people to own slaves and for women not to vote. Common sense, moreover, is not always ''common'' -- the idea that lesbians and gay men should be protected against discrimination and violence strikes some people as common-sensical, but for others it threatens the foundations of ordinary life.

If common sense sometimes preserves the social status quo, and that status quo sometimes treats unjust social hierarchies as natural, it makes good sense on such occasions to find ways of challenging common sense. Language that takes up this challenge can help point the way to a more socially just world. The contemporary tradition of critical theory in the academy, derived in part from the Frankfurt School of German anti-fascist philosophers and social critics, has shown how language plays an important role in shaping and altering our common or ''natural'' understanding of social and political realities.

The philosopher Theodor W. Adorno, who maintained that nothing radical could come of common sense, wrote sentences that made his readers pause and reflect on the power of language to shape the world. A sentence of his such as ''Man is the ideology of dehumanization'' is hardly transparent in its meaning. Adorno maintained that the way the word ''man'' was used by some of his contemporaries was dehumanizing.

Taken out of context, the sentence may seem vainly paradoxical. But it becomes clear when we recognize that in Adorno's time the word ''man'' was used by humanists to regard the individual in isolation from his or her social context. For Adorno, to be deprived of one's social context was precisely to suffer dehumanization. Thus, ''man'' is the ideology of dehumanization.

Herbert Marcuse once described the way philosophers who champion common sense scold those who propagate a more radical perspective: ''The intellectual is called on the carpet. . . . Don't you conceal something? You talk a language which is suspect. You don't talk like the rest of us, like the man in the street, but rather like a foreigner who does not belong here. We have to cut you down to size, expose your tricks, purge you.''

The accused then responds that ''if what he says could be said in terms of ordinary language he would probably have done so in the first place.'' Understanding what the critical intellectual has to say, Marcuse goes on, ''presupposes the collapse and invalidation of precisely that universe of discourse and behavior into which you want to translate it.''

Of course, translations are sometimes crucial, especially when scholars teach. A student for whom a word such as ''hegemony'' appears strange might find that it denotes a dominance so entrenched that we take it for granted, and even appear to consent to it -- a power that's strengthened by its invisibility.

One may have doubts that ''hegemony'' is needed to describe how power haunts the common-sense world, or one may believe that students have nothing to learn from European social theory in the present academy. But then we are no longer debating the question of good and bad writing, or of whether ''hegemony'' is an unlovely word. Rather, we have an intellectual disagreement about what kind of world we want to live in, and what intellectual resources we must preserve as we make our way toward the politically new