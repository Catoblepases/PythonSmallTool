---
url: https://www.nature.com/articles/d41586-022-02823-4
readlater:
  id: "1536702482"
  provider: instapaper
  synchtime: 1701965975510
---
- NEWS FEATURE
- 07 September 2022

# What scientists have learnt from COVID lockdowns

Restrictions on social contact stemmed disease spread, but weighing up the ultimate costs and benefits of lockdown measures is a challenge.

By- [Dyani Lewis](#author-0)[0](#Aff0)

1. Dyani Lewis
    
    1. Dyani Lewis is freelance reporter in Melbourne, Australia.
        
    
    [View author publications](/search?author=Dyani+Lewis)
    
    You can also search for this author in [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Dyani+Lewis)  [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&btnG=Search+Scholar&as_sauthors=%22Dyani%2BLewis%22)
    

- [Twitter](https://twitter.com/intent/tweet?text=What+scientists+have+learnt+from+COVID+lockdowns&url=https%3A%2F%2Fwww.nature.com%2Farticles%2Fd41586-022-02823-4)
- [Facebook](http://www.facebook.com/sharer.php?u=https%3A%2F%2Fwww.nature.com%2Farticles%2Fd41586-022-02823-4)
- [Email](mailto:?subject=What scientists have learnt from COVID lockdowns&body=https%3A%2F%2Fwww.nature.com%2Farticles%2Fd41586-022-02823-4)

 ![A man crosses an empty highway road on 3 February 2020 in Wuhan, Hubei province, China.](//media.nature.com/w767/magazine-assets/d41586-022-02823-4/d41586-022-02823-4_23406598.jpg)

A man walks across a deserted highway in Wuhan, China, in February 2020, during the city’s first lockdown. Credit: Getty Images

[Access through your institution](https://wayf.springernature.com?redirect_uri=https%3A%2F%2Fwww.nature.com%2Farticles%2Fd41586-022-02823-4)

[Buy or subscribe](#access-options)

In March 2021, a doctor in Brazil named Ricardo Savaris published a now-discredited research paper that went viral on social media[1](#ref-CR1).

## Access options

[Access through your institution](https://wayf.springernature.com?redirect_uri=https%3A%2F%2Fwww.nature.com%2Farticles%2Fd41586-022-02823-4)

[Access through your institution](https://wayf.springernature.com?redirect_uri=https%3A%2F%2Fwww.nature.com%2Farticles%2Fd41586-022-02823-4)

[Change institution](https://wayf.springernature.com?redirect_uri=https%3A%2F%2Fwww.nature.com%2Farticles%2Fd41586-022-02823-4)

[Buy or subscribe](#access-options)

Access Nature and 54 other Nature Portfolio journals

Get Nature+, our best-value online-access subscription

24,99 € / 30 days

cancel any time

[Learn more](https://shop.nature.com/products/plus)

Subscribe to this journal

Receive 51 print issues and online access

199,00 € per year

only 3,90 € per issue

[Learn more](/nature/subscribe)

Rent or buy this article

Prices vary by article type

from$1.95

to$39.95

[Learn more](//www.nature.com/articles/d41586-022-02823-4.epdf?no_publisher_access=1&r3_referer=nature)

Prices may be subject to local taxes which are calculated during checkout

### Additional access options:

- [Log in](https://idp.nature.com/authorize/natureuser?client_id=grover&redirect_uri=https%3A%2F%2Fwww.nature.com%2Farticles%2Fd41586-022-02823-4)
- [Learn about institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/license-options)
- [Read our FAQs](https://support.nature.com/en/support/home)
- [Contact customer support](https://www.springernature.com/gp/contact)

_Nature_ **609**, 236-239 (2022)

_doi: https://doi.org/10.1038/d41586-022-02823-4_

## References

1. Savaris, R. F., Pumi, G., Dalzochio, J. & Kunst, R. _Sci. Rep._ **11**, 5313 (2021); retraction **11**, 24172 (2021).
    
    [Article](https://doi.org/10.1038%2Fs41598-021-84092-1)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=33674661)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Sci.%20Rep.&doi=10.1038%2Fs41598-021-84092-1&volume=11&publication_year=2021&author=Savaris%2CR.%20F.&author=Pumi%2CG.&author=Dalzochio%2CJ.&author=Kunst%2CR.) 
    
2. Meyerowitz-Katz, G., Besançon, L., Flahault, A. & Wimmer, R. _Sci. Rep._ **11**, 23533 (2021).
    
    [Article](https://doi.org/10.1038%2Fs41598-021-02461-2)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34876624)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Sci.%20Rep.&doi=10.1038%2Fs41598-021-02461-2&volume=11&publication_year=2021&author=Meyerowitz-Katz%2CG.&author=Besan%C3%A7on%2CL.&author=Flahault%2CA.&author=Wimmer%2CR.) 
    
3. Góes, C. _Sci. Rep._ **11**, 23044 (2021).
    
    [Article](https://doi.org/10.1038%2Fs41598-021-02096-3)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34845244)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Sci.%20Rep.&doi=10.1038%2Fs41598-021-02096-3&volume=11&publication_year=2021&author=G%C3%B3es%2CC.) 
    
4. Flaxman, S. _et al._ _Nature_ **584**, 257–261 (2020).
    
    [Article](https://doi.org/10.1038%2Fs41586-020-2405-7)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=32512579)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Nature&doi=10.1038%2Fs41586-020-2405-7&volume=584&pages=257-261&publication_year=2020&author=Flaxman%2CS.) 
    
5. Berry, C. R., Fowler, A., Glazer, T., Handel-Meyer, S. & MacMillen, A. _Proc. Natl Acad. Sci. USA_ **118**, e2019706118 (2021).
    
    [Article](https://doi.org/10.1073%2Fpnas.2019706118)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=33766888)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Proc.%20Natl%20Acad.%20Sci.%20USA&doi=10.1073%2Fpnas.2019706118&volume=118&publication_year=2021&author=Berry%2CC.%20R.&author=Fowler%2CA.&author=Glazer%2CT.&author=Handel-Meyer%2CS.&author=MacMillen%2CA.) 
    
6. Halet, T. _et al._ _PLoS ONE_ **16**, e0253116 (2021).
    
    [Article](https://doi.org/10.1371%2Fjournal.pone.0253116)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34242239)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=PLoS%20ONE&doi=10.1371%2Fjournal.pone.0253116&volume=16&publication_year=2021&author=Halet%2CT.) 
    
7. Haug, N. _et al._ _Nature Hum. Behav._ **4**, 1303–1312 (2020).
    
    [Article](https://doi.org/10.1038%2Fs41562-020-01009-0)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=33199859)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Nature%20Hum.%20Behav.&doi=10.1038%2Fs41562-020-01009-0&volume=4&pages=1303-1312&publication_year=2020&author=Haug%2CN.) 
    
8. Brauner, J. M. _et al._ _Science_ **371**, eabd9338 (2021).
    
    [Article](https://doi.org/10.1126%2Fscience.abd9338)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=33323424)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Science&doi=10.1126%2Fscience.abd9338&volume=371&publication_year=2021&author=Brauner%2CJ.%20M.) 
    
9. Independent Panel on Pandemic Preparedness & Response. _COVID-19: Make It the Last Pandemic_ (IPPPR, 2021).
    
    [Google Scholar](http://scholar.google.com/scholar_lookup?&title=COVID-19%3A%20Make%20It%20the%20Last%20Pandemic&publication_year=2021) 
    
10. Knock, E. S. _et al._ _Sci. Transl. Med._ **13**, eabg4262 (2021).
    
    [Article](https://doi.org/10.1126%2Fscitranslmed.abg4262)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34158411)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Sci.%20Transl.%20Med.&doi=10.1126%2Fscitranslmed.abg4262&volume=13&publication_year=2021&author=Knock%2CE.%20S.) 
    
11. Chen, S. _et al._ _Int. J. Environ. Res. Public Health_ **18**, 8686 (2021).
    
    [Article](https://doi.org/10.3390%2Fijerph18168686)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34444434)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Int.%20J.%20Environ.%20Res.%20Public%20Health&doi=10.3390%2Fijerph18168686&volume=18&publication_year=2021&author=Chen%2CS.) 
    
12. Sharma, M. _et al._ _Nature Commun._ **12**, 5820 (2021).
    
    [Article](https://doi.org/10.1038%2Fs41467-021-26013-4)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34611158)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Nature%20Commun.&doi=10.1038%2Fs41467-021-26013-4&volume=12&publication_year=2021&author=Sharma%2CM.) 
    
13. Phillips, T., Zhang, Y. & Petherick, A. _Interface Focus_ **11**, 20210041 (2021).
    
    [Article](https://doi.org/10.1098%2Frsfs.2021.0041)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34956599)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Interface%20Focus&doi=10.1098%2Frsfs.2021.0041&volume=11&publication_year=2021&author=Phillips%2CT.&author=Zhang%2CY.&author=Petherick%2CA.) 
    
14. Chang, S. _et al._ _Nature_ **589**, 82–87 (2021).
    
    [Article](https://doi.org/10.1038%2Fs41586-020-2923-3)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=33171481)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Nature&doi=10.1038%2Fs41586-020-2923-3&volume=589&pages=82-87&publication_year=2021&author=Chang%2CS.) 
    
15. Zhang, H. _et al._ _Front. Public Health_ **10**, 859751 (2022).
    
    [Article](https://doi.org/10.3389%2Ffpubh.2022.859751)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=35619804)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Front.%20Public%20Health&doi=10.3389%2Ffpubh.2022.859751&volume=10&publication_year=2022&author=Zhang%2CH.) 
    
16. Broughel, J. & Kotrous, M. _PLoS ONE_ **16**, e0252729 (2021).
    
    [Article](https://doi.org/10.1371%2Fjournal.pone.0252729)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34081757)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=PLoS%20ONE&doi=10.1371%2Fjournal.pone.0252729&volume=16&publication_year=2021&author=Broughel%2CJ.&author=Kotrous%2CM.) 
    
17. Department of Health and Social Care, Office for National Statistics, Government Actuary’s Department and Home Office. _Direct and Indirect Impacts of COVID-19 on Excess Deaths and Morbidity: Executive Summary — 15 July 2020_ (UK Government, 2020).
    
    [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Direct%20and%20Indirect%20Impacts%20of%20COVID-19%20on%20Excess%20Deaths%20and%20Morbidity%3A%20Executive%20Summary%20%E2%80%94%2015%20July%202020&publication_year=2020) 
    
18. Robinson, L. A., Sullivan. R. & Shogren, J. F. _Risk Anal._ **41**, 761–770 (2020).
    
    [Article](https://doi.org/10.1111%2Frisa.13561)  [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=32677076)  [Google Scholar](http://scholar.google.com/scholar_lookup?&title=&journal=Risk%20Anal.&doi=10.1111%2Frisa.13561&volume=41&pages=761-770&publication_year=2020&author=Robinson%2CL.%20A.&author=Sullivan%2CR.&author=Shogren%2CJ.%20F.) 
    

[Download references](https://citation-needed.springer.com/v2/references/10.1038/d41586-022-02823-4?format=refman&flavour=references)

[Reprints and Permissions](https://s100.copyright.com/AppDispatchServlet?title=What%20scientists%20have%20learnt%20from%20COVID%20lockdowns&author=Dyani%20Lewis&contentID=10.1038%2Fd41586-022-02823-4&copyright=Springer%20Nature%20Limited&publication=0028-0836&publicationDate=2022-09-07&publisherName=SpringerNature&orderBeanReset=true)

## Related Articles

-  [![](//media.nature.com/lw100/magazine-assets/d41586-022-02823-4/d41586-022-02823-4_22170282.jpg) The pandemic’s true health cost: how much of our lives has COVID stolen?](https://www.nature.com/articles/d41586-022-01341-7)
    
-  [![](//media.nature.com/lw100/magazine-assets/d41586-022-02823-4/d41586-022-02823-4_23399648.jpg) Could tiny blood clots cause long COVID’s puzzling symptoms?](https://www.nature.com/articles/d41586-022-02286-7)
    

## Subjects

- [SARS-CoV-2](/subjects/sars-cov-2)
- [Diseases](/subjects/diseases)
- [Policy](/subjects/policy)

## Latest on:

SARS-CoV-2

[![Self-copying RNA vaccine wins first full approval: what’s next?](https://images.nature.com/w140h79/magazine-assets/d41586-023-03859-w/d41586-023-03859-w_26494158.jpg)

Self-copying RNA vaccine wins first full approval: what’s next?

News 06 DEC 23

](https://www.nature.com/articles/d41586-023-03859-w)

[![These volunteers want to be infected with disease to aid research — will their altruism help?](https://images.nature.com/w140h79/magazine-assets/d41586-023-03583-5/d41586-023-03583-5_26337192.jpg)

These volunteers want to be infected with disease to aid research — will their altruism help?

News Feature 28 NOV 23

](https://www.nature.com/articles/d41586-023-03583-5)

[![What’s behind China’s mysterious wave of childhood pneumonia?](https://images.nature.com/w140h79/magazine-assets/d41586-023-03732-w/d41586-023-03732-w_26361442.jpg)

What’s behind China’s mysterious wave of childhood pneumonia?

News Explainer 27 NOV 23

](https://www.nature.com/articles/d41586-023-03732-w)

Diseases

[![Are your organs ageing well? The blood holds clues](https://images.nature.com/w140h79/magazine-assets/d41586-023-03821-w/d41586-023-03821-w_26494170.jpg)

Are your organs ageing well? The blood holds clues

News 06 DEC 23

](https://www.nature.com/articles/d41586-023-03821-w)

[

Reverse metabolomics for the discovery of chemical structures from humans

Article 05 DEC 23

](https://www.nature.com/articles/s41586-023-06906-8)

[![Climate change is also a health crisis — these 3 graphics explain why](https://images.nature.com/w140h79/magazine-assets/d41586-023-03804-x/d41586-023-03804-x_26478714.jpg)

Climate change is also a health crisis — these 3 graphics explain why

News Explainer 01 DEC 23

](https://www.nature.com/articles/d41586-023-03804-x)

Policy

[

Nature-based climate solutions: align policy with science

Correspondence 05 DEC 23

](https://www.nature.com/articles/d41586-023-03855-0)

[

A system-transitions report for the next IPCC assessment cycle

Correspondence 05 DEC 23

](https://www.nature.com/articles/d41586-023-03857-y)

[![Combat corporate greenwashing with better science](https://images.nature.com/w140h79/magazine-assets/d41586-023-03815-8/d41586-023-03815-8_26494000.jpg)

Combat corporate greenwashing with better science

Editorial 05 DEC 23

](https://www.nature.com/articles/d41586-023-03815-8)

## ![Nature Careers](/static/images/logos/nature-careers-logo-f6ff1c1c64.svg)

### [Jobs](https://www.nature.com/naturecareers/)

- #### [Wallenberg - NTU Presidential Postdoctoral Fellowship 2024](https://www.nature.com/naturecareers/job/12811281/wallenberg-ntu-presidential-postdoctoral-fellowship-2024/?TrackID=62&utm_source=widget&utm_medium=referral&utm_campaign=62)
    
    Call for Application: Wallenberg - NTU Presidential Postdoctoral Fellowship 2024 from now to 31 Jan 2024
    
    Singapore (SG)
    
    Nanyang Technological University (NTU)
    
    ![](https://www.nature.com/naturecareers/getasset/c9a3c099-f625-47a4-acdd-ea58b3dfb83e/)
    
- #### [Global Scientist Interdisciplinary Forum & Recruitment](https://www.nature.com/naturecareers/job/12811265/global-scientist-interdisciplinary-forum-and-recruitment-/?TrackID=62&utm_source=widget&utm_medium=referral&utm_campaign=62)
    
    Southern University of Science and Technology, School of Medicine
    
    Shenzhen, Guangdong, China
    
    Southern University of Science and Technology, School of Medicine
    
    ![](https://www.nature.com/naturecareers/getasset/3170f091-4010-484c-b45c-cfe00497f3e9/)
    
- #### [Postdoctoral Research Fellow at the Dalian Institute of Chemical Physics](https://www.nature.com/naturecareers/job/12798448/postdoctoral-research-fellow-at-the-dalian-institute-of-chemical-physics/?TrackID=62&utm_source=widget&utm_medium=referral&utm_campaign=62)
    
    Located in the beautiful coastal city of Dalian, surrounded by mountains and sea, DICP seeks all talents from around the globe.
    
    Dalian, Liaoning, China
    
    The Dalian Institute of Chemical Physics (DICP)
    
    ![](https://www.nature.com/naturecareers/getasset/e13b48f3-597e-4cb9-96fa-bac6a3156c72/)
    
- #### [Postdoctoral Associate- Cardiac Regeneration](https://www.nature.com/naturecareers/job/12811242/postdoctoral-associate-cardiac-regeneration/?TrackID=62&utm_source=widget&utm_medium=referral&utm_campaign=62)
    
    Houston, Texas (US)
    
    Baylor College of Medicine (BCM)
    
    ![](https://www.nature.com/naturecareers/getasset/eb5c581a-539f-439b-a848-eb32e266d6f5/)
    
- #### [Research Scientist](https://www.nature.com/naturecareers/job/12811191/research-scientist/?TrackID=62&utm_source=widget&utm_medium=referral&utm_campaign=62)
    
    Position: Research Scientist
    
    Saudi Arabia (SA)
    
    King Abdullah International Medical Research Center
    
    ![](https://www.nature.com/naturecareers/getasset/93128106-8e8b-409f-8c67-89f8fc8ef3f5/)