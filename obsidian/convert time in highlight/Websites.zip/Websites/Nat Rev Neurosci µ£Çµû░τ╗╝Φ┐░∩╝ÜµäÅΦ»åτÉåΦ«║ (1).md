---
url: http://mp.weixin.qq.com/s?__biz=MzI2ODEyOTE3OQ==&mid=2649637205&idx=1&sn=d50045f5319b971cc6f013884655ec99&chksm=f2eea7a1c5992eb79fd7aae20942c5440e97a430421fe45da03f8ab5ab2449b40d9b52532438#rd
readlater:
  id: "1512477587"
  provider: instapaper
  synchtime: 1701965977284
---
             

# Nat Rev Neurosci 最新综述：意识理论

Original brainnews创作团队 [brainnews](javascript:void(0);)

**brainnews** 

Weixin ID brainnews

About Feature 国内领先的脑科学自媒体，分享脑科学，服务脑科学工作者。

_Posted on_

收录于合集 #脑科学前沿 747个

**[](http://mp.weixin.qq.com/s?__biz=MzI2ODEyOTE3OQ==&mid=2649589238&idx=6&sn=a3535bde9004933c57064b81312882d9&chksm=f2ed6302c59aea14f13aa94ebfee725f3b35bc91c197a99883d11dd8cc64edc44f09de5b2493&scene=21#wechat_redirect)[](http://mp.weixin.qq.com/s?__biz=MzI2ODEyOTE3OQ==&mid=2649634806&idx=1&sn=de98abdb71558f6776a74214c0728b1b&chksm=f2eed102c599581412ba39b522b98fb518e620b87e8bba0ed39dbd2fd340b51136dec5cb1155&scene=21#wechat_redirect)**

近年来，关于**意识的生物学和物理基础的理论**不断被提出，然而目前还不清楚当前的理论是如何相互联系的，或者它们是否可以通过经验加以区分。

  

Anil S和Tim B教授根据该问题，总结了近年来比较突出的**四类意识理论**，提出了一些建议以促进意识理论的发展并将其成果_**“Theories of consciousness”**_于2022年5月发表于**_Nature Reviews Neuroscience_**杂志。

  

  

  

欢迎加入

**全国****认知心理****学术讨论群**

添加小编微信

**brainnews_11**

-留言：**认知心理**研究群-

  

  

  

  

**********高阶理论(HOTs)**********  

  

所有HOTs的核心主张是一种心理状态变成有意识的是因为他们成为了**元心理状态**（高阶表象）**的目标**（图1）。也就是说，如果这个心理状态是有意识的，那么必定存在另一个把这个心理状态作为对象的高阶表象。可以看出**HOTs解释的是为什么一些内容是有意识的，而且关注的是意识的整体状态。**

  

HOTs认为一种状态的现象特征是**由相关的高阶表象赋予它的属性所决定的**，以此来解释为什么不同的经历有着不同的现象特征。但是为什么高阶表象可以产生不同属性，以及它背后的神经活动是什么，目前都还未得到完善的解释。目前**HOTs认为皮质前部，尤其是前额叶皮质在高阶表象中有着重要的作用，但目前尚无定论。**

  

图1. 高阶理论

  

  

**********全局工作空间理论(GWT)**********

  

GWTs提议**将大脑分为执行不同功能的专用模块****，模块与模块之间具有长距离连接**。通过注意选择的过程确定输入或任务要求后，专用模块内的信息可以在不同模块之间传播与共享，其核心主张是**每一时刻的及时共享信息**（即全局工作空间）**构成了意识**（图2）。该理论的提出**一开始关注于认知层面，之后发展到神经元层面**（全局神经元工作空间理论）。

  

与HOTs一样，GWTs也着眼的是“是什么让一种表现变得有意识”。但是GWTs更关注**意识的功能特征**（某种精神状态凭借意识在生物体的认知中所起的作用），而不是现象特征。GWTs认为**额-顶叶区域是其中心点**。但是该类理论的一个需要回答的问题是，“全局”的定义是什么？

  

图2. 全局工作空间理论

  

  

  

**信息整合理论(IIT)**

  

IIT**假设意识体验的现象特征为公理**，由此衍生出相关的公设，并构建了一套**几何式现象学公理化系统去解释意识**，该理论认为，**意识是大脑皮层在一定时间内大量信息整合的结果**，是系统中内在的本质的特性，由组成它的因果机制的性质和它们的状态所决定（图3）。该理论认为**任何系统，只要产生了一个非零的不可约的整合信息的最大值，那么就可以是有意识的**。

  

IIT主要将意识与皮层后部（顶叶、颞叶和枕叶区域）联系起来，部分是因为这些区域的解剖学特性可以支持信息整合。IIT以用系统产生的不可约的整合信息的数量（Φ）来解释整体状态，以概念结构来解释局部状态的经验特征。

  

图3. 信息整合理论

  

  

**********再入和预测处理理论**********

  

再入理论和预测处理理论强调**自上而下的信号对形成和塑造有意识的感知的重要性**。再入理论认为感知皮层内的局部的信息再发生和再处理足以产生意识，预测处理理论认为大脑通过(自上向下的)感知预测和(自下向上的)预测错误的交互实现了一个“预测误差最小化”的过程（后者其实并不是意识理论，但是其与意识科学相关，能够更好地提供神经机制和现象学性质之间的系统关联）（图4）。

  

预测处理理论以自上而下的感知预测的内容来解释局部的意识状态，即**感知内容是由大脑对感官产生的原因的“最佳猜测”给出的，它区分意识和无意识状态是判断这种心理状态是否是当前 “最佳猜测”的一部分**。

  

图4. 再入和预测处理理论

  

  

**

******对意识理论的评估和建议******

**

  

关于意识理论之间的争辩很多，其中主要有三个限制因素。其一是**意识的结构**，主要是指意识的统一性，即有意识的个体对事物的体验具有统一的意识域。不同的意识理论对意识的统一性的态度有所不同。其二是**来源于神经科学的数据**，主要是对前额叶对意识的作用的争议，不同的神经范式、神经影像学资料显示前额叶参与了意识，然而不同的理论对此的看法不同。

  

HOTs和GETs认为上述结果支持了它们的理论，然而IIT和再入理论认为这些观察到的前额叶的神经活动仅仅是意识的非必要的结果，与认知通路（精神状态可以访问各种认知过程的功能性属性，通常包括语言/行为报告）相关，而不是意识本身。其三是**意识理论做出的新的预测**。然而，现有的意识理论所做出的预测都很难被检验和证实。

  

Anil S和Tim B教授认为**或许解决一些意识理论中现存的问题可以促进其发展。**其一是**意识理论应该要更加精确和具体**，使用计算机模型或许会是一个好方法。其二是**意识理论应该更加全面**，现有的意识理论总是局限于解释意识的某个方面，无论是局部状态还是总体状态，倘若意识理论能将意识的各个方面解释清楚，那会更加可信。其三是**意识的测量问题**，现有的测量意识的方法主要是依靠受试者的主观内省能力，然而这种方法的可靠性无法确定，而且对于那些出现脑损伤以及婴儿等无法表达的个体，这种方法也无法进行。

  

  

**

结 论

**

  

**现有不同的意识理论试图去解释意识的不同方面，然而它们之间经常无法互相说服和联系，未来应当有更准确的方法去更加精确、具体、全面地构建意识理论。**

  

  

**参考文献**

Anil S and Tim B. Theories of consciousness. Nature Reviews Neuroscience, 2022. DOI: 10.1038/s41583-022-00587-4.

**编译作者：KK****（brainnews创作团队）**

**校审：Simon（brainnews编辑部）**

  

  

**往**

# [**Nature Reviews Neuroscience 综述收藏：丘脑前核群-海马-皮质的三方记忆系统理论**](https://mp.weixin.qq.com/s?__biz=MzI2ODEyOTE3OQ==&mid=2649636385&idx=1&sn=725eb576c702d8fcd860868faec16c17&chksm=f2eed8d5c59951c39df509d6ba842d6ad174e037f1444190f4f6c040fde14ba26496e2297ffb&token=1581855821&lang=zh_CN&scene=21#wechat_redirect)  

**期**

# [**Neuron：社交记忆调控的新环路机制**](https://mp.weixin.qq.com/s?__biz=MzI2ODEyOTE3OQ==&mid=2649636347&idx=1&sn=ff8463f16f472ccc413c3c0bcddde49f&chksm=f2eedb0fc59952195df1e8e177861ede41fc43f33aa1afe1df71e61e975f46988647b9a660f3&token=1581855821&lang=zh_CN&scene=21#wechat_redirect)

**推**

# [**Prog Neurobiol：南开大学张涛/吴世安团队发现阿尔茨海默病治疗的潜在新靶点**](https://mp.weixin.qq.com/s?__biz=MzI2ODEyOTE3OQ==&mid=2649636133&idx=1&sn=e728c1852d9b26a5ceaa3e967d27576c&chksm=f2eedbd1c59952c7f9782575041cb9353971d4c5b65ec49b56ee2e9792cccd59f5170afef2d2&token=1581855821&lang=zh_CN&scene=21#wechat_redirect)

**荐**

# **[Science：小胶质细胞的功能再次被挖掘！研究揭示其参与神经病理性疼痛的缓](https://mp.weixin.qq.com/s?__biz=MzI2ODEyOTE3OQ==&mid=2649636034&idx=1&sn=3d7b53252a37bc32e05bc3e565438ee7&chksm=f2eeda36c5995320ed5cee5ae835f8869166ef0c261e76b8762971fffb4a8c95a9e3ce0f1fdd&token=1581855821&lang=zh_CN&scene=21#wechat_redirect)**

  

  

[](https://mp.weixin.qq.com/s?__biz=MzI2ODEyOTE3OQ==&mid=2649584994&idx=2&sn=a0cc25df475337d6ac84f91c1819f082&chksm=f2ed9396c59a1a80d240f4e69df1403462873f5b590a7b0b4edea6d82872dd89b6c85024e210&scene=21#wechat_redirect)

[](https://mp.weixin.qq.com/s?__biz=MzA5OTUzOTAxNw==&mid=2648969729&idx=1&sn=87a7c00074626c7d6cb7d6f37c358ddf&chksm=88907327bfe7fa313432308d7261c895dadc1cb1d2ba928759781cedf41da98b632b2529803f&sessionid=0&clicktime=1648458214&enterid=1648458214&ascene=21&devicetype=iOS14.8&version=1800123a&nettype=WIFI&lang=zh_CN&fontScale=100&exportkey=AwU35IXJwS58SRbJT9UCUtI=&pass_ticket=yiM AiLjj1ULWVjVC6QE D4Jw/CjWSX0K67l1/COkXl6Dnnq/ng6AgUyM0irkfje&wx_header=3&scene=21#wechat_redirect)

[](https://mp.weixin.qq.com/s?__biz=MzI0MDgyMDg1OQ==&mid=2247484735&idx=1&sn=72b094c9cc94b635099a52e1554fd1e4&scene=21&token=1293754700&lang=zh_CN#wechat_redirect)

[](https://mp.weixin.qq.com/s?__biz=MzkzMzIwMjUzMA==&mid=2247485456&idx=1&sn=2b7fa27adac4bc2a6774ad10e1d01feb&scene=21#wechat_redirect)

[](https://mp.weixin.qq.com/s?__biz=Mzg2MjE0ODQ1MQ==&mid=2247484433&idx=1&sn=e9085f4a9a5d12669f1bcc5d16dc571a&scene=21&token=1293754700&lang=zh_CN#wechat_redirect)

[](https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzAxMjA0NjI2MQ==&action=getalbum&album_id=1488833136619765767&devicetype=iOS14.8&version=1800123a&lang=zh_CN&nettype=WIFI&ascene=0&fontScale=100&pass_ticket=yiM%2BAiLjj1ULWVjVC6QE%2BD4Jw%2FCjWSX0K67l1%2FCOkXl6Dnnq%2Fng6AgUyM0irkfje&wx_header=3&scene=21&token=1293754700#wechat_redirect)

[](https://mp.weixin.qq.com/s?__biz=MzUxNzM2NTM2Mw==&mid=2247495508&idx=1&sn=4eb6968b8e416f99acf55e88a897e659&scene=21#wechat_redirect)

[](http://mp.weixin.qq.com/s?__biz=MzUzMzA4NDU4OQ==&mid=2247514966&idx=3&sn=dc657ef1b473a7f4dfef32034aad8a2c&chksm=faab9b94cddc1282b876042c3bdd037be9898fff84eaa794feb2729a9f3f93128fcf877e6a6c&scene=21#wechat_redirect)

预览时标签不可点

Scan to Follow

轻触阅读原文

 

继续滑动看下一个

[Got It](javascript:;)

 

 Scan with Weixin to  
use this Mini Program

[Cancel](javascript:void(0);) [Allow](javascript:void(0);)

[Cancel](javascript:void(0);) [Allow](javascript:void(0);)

 : ， .   Video Mini Program Like ，轻点两下取消赞 Wow ，轻点两下取消在看