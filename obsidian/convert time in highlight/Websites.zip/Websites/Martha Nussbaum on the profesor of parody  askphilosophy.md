---
doc_type: website
url: https://www.reddit.com/r/askphilosophy/comments/73b3jt/martha_nussbaum_on_the_profesor_of_parody/
date created: 2023-08-22
date modified: 2023-08-22
---
Martha Nussbaum writes a criticism of Judith Butler works, and more importantly her "way" of arguing and theorizing.

> Feminist thinkers of the new symbolic type would appear to believe that the way to do feminist politics is to use words in a subversive way, in academic publications of lofty obscurity and disdainful abstractness

Is there a name or influence that we could group those types of works together? a umbrella where they more or less fit?

She claims

> These developments owe much to the recent prominence of French postmodernist thought. Many young feminists, whatever their concrete affiliations with this or that French thinker, have been influenced by the extremely French idea that the intellectual does politics by speaking seditiously, and that this is a significant type of political action. Many have also derived from the writings of Michel Foucault …

and cites Focault as one example. However I keep seeing here people deying that Focault was a postmodernist or that we can use the word postmodernism to describe this particular kind of work. In fact, for the way that is argued in this sub, I started thinking that the label of postmodernism had no possible application whatsoever to anyone.

Regardless if you disagree with Nussbaum she is clearly no hack or bad philosopher, so can someone tell me what characteristics shares those works that she is criticizing? what do they seem to offer that other kind of analytic and rigorous, less based on personal experiences, work lacks?
