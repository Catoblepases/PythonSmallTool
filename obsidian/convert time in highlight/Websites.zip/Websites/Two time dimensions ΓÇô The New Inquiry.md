---
url: https://thenewinquiry.com/blog/two-time-dimensions/
readlater:
  id: "1534092565"
  provider: instapaper
  synchtime: 1701965980164
---
[Skip to content](#content)

Menu

[The New Inquiry](https://thenewinquiry.com/)

The New Inquiry is a space for discussion that aspires to enrich cultural and public life by putting all available resources—both digital and material—toward the promotion and exploration of ideas.

- **Error:** Could not authenticate you.
    

- [Facebook](https://www.facebook.com/TheNewInquiry)
- [Twitter](https://twitter.com/newinquiry/)
- [Tumblr](https://thenewinquiry.tumblr.com/)
- [Instagram](https://www.instagram.com/newinquiry/)
- [RSS](/rss)

- [Subscribe](https://members.thenewinquiry.com)

- [Essays & Reviews](https://thenewinquiry.com/category/essays-reviews/)
- [Features](https://thenewinquiry.com/category/features/)
- [Blogs](https://thenewinquiry.com/blog/)
- [Audio](https://thenewinquiry.com/tag/audio/)
- [Current Issue](https://thenewinquiry.com/magazine/assets/)
- [Past Issues](https://thenewinquiry.com/magazine/)
- [Shop](https://the-new-inquiry-store.myshopify.com/)
- [About](https://thenewinquiry.com/about/)
- [Search](#)
- [Login](#)
- [Subscribe for $2](https://members.thenewinquiry.com)

Search for:  Search

# 404: Page not found

It looks like nothing was found at this location. Maybe try a search or one of the links below?

Search for:  Search

## Recent Posts

- [PACBI Now](https://thenewinquiry.com/pacbi-now/)
- [Exposed Bricks](https://thenewinquiry.com/exposed-bricks/)
- [The Second Week](https://thenewinquiry.com/the-second-week/)
- [The First Week](https://thenewinquiry.com/the-first-week/)
- [Alienated Nerds](https://thenewinquiry.com/alienated-nerds/)

## Archives

Archives Select Month November 2023 October 2023 September 2023 July 2023 June 2023 April 2023 February 2023 December 2022 October 2022 August 2022 July 2022 June 2022 May 2022 March 2022 February 2022 September 2021 June 2021 May 2021 November 2020 August 2020 July 2020 June 2020 May 2020 April 2020 March 2020 February 2020 December 2019 November 2019 October 2019 September 2019 August 2019 July 2019 June 2019 May 2019 April 2019 March 2019 January 2019 December 2018 November 2018 October 2018 September 2018 August 2018 July 2018 June 2018 May 2018 April 2018 March 2018 February 2018 January 2018 December 2017 November 2017 October 2017 September 2017 August 2017 July 2017 June 2017 May 2017 April 2017 March 2017 February 2017 January 2017 December 2016 November 2016 October 2016 September 2016 August 2016 July 2016 June 2016 May 2016 April 2016 March 2016 February 2016 January 2016 December 2015 November 2015 October 2015 September 2015 August 2015 July 2015 June 2015 May 2015 April 2015 March 2015 February 2015 January 2015 December 2014 November 2014 October 2014 September 2014 August 2014 July 2014 June 2014 May 2014 April 2014 March 2014 February 2014 January 2014 December 2013 November 2013 October 2013 September 2013 August 2013 July 2013 June 2013 May 2013 April 2013 March 2013 February 2013 January 2013 December 2012 November 2012 October 2012 September 2012 August 2012 July 2012 June 2012 May 2012 April 2012 March 2012 February 2012 January 2012 December 2011 November 2011 October 2011 September 2011 August 2011 July 2011 June 2011 May 2011 April 2011 March 2011 February 2011 January 2011 November 2010 October 2010 September 2010 August 2010 July 2010 May 2010 February 2010 January 2010 December 2009 November 2009 October 2009 

## Categories

Categories Select Category &, Meanwhile A/V Audio Dark Inquiry Dispatch Essays & Reviews Features News Reading Lists Special Projects Sunday Reading Uncategorized

## Tags

[archive](https://thenewinquiry.com/tag/archive/) [art](https://thenewinquiry.com/tag/art/) [Aspect Ratio](https://thenewinquiry.com/tag/aspect-ratio/) [audio](https://thenewinquiry.com/tag/audio/) [big data](https://thenewinquiry.com/tag/big-data/) [book review](https://thenewinquiry.com/tag/book-review/) [capitalism](https://thenewinquiry.com/tag/capitalism/) [cinema](https://thenewinquiry.com/tag/cinema/) [criticism](https://thenewinquiry.com/tag/criticism/) [death](https://thenewinquiry.com/tag/death/) [Escape From Venice](https://thenewinquiry.com/tag/escape-from-venice/) [essay](https://thenewinquiry.com/tag/essay/) [essays](https://thenewinquiry.com/tag/essays/) [feminism](https://thenewinquiry.com/tag/feminism/) [food history](https://thenewinquiry.com/tag/food-history/) [food news](https://thenewinquiry.com/tag/food-news/) [history](https://thenewinquiry.com/tag/history/) [history of dialogue](https://thenewinquiry.com/tag/history-of-dialogue/) [Interview](https://thenewinquiry.com/tag/interview/) [Israel](https://thenewinquiry.com/tag/israel/) [Italy](https://thenewinquiry.com/tag/italy/) [literature](https://thenewinquiry.com/tag/literature/) [Money](https://thenewinquiry.com/tag/money/) [No. 1: Precarity](https://thenewinquiry.com/tag/no-1-precarity/) [No. 3: Arguing the Web](https://thenewinquiry.com/tag/no-3-arguing-the-web/) [No. 6: Game of Drones](https://thenewinquiry.com/tag/no-6-game-of-drones/) [No. 9: Concept Album](https://thenewinquiry.com/tag/no-9-concept-album/) [No. 10: Gossip](https://thenewinquiry.com/tag/no-10-gossip/) [No. 11: Feast and Famine](https://thenewinquiry.com/tag/no-11-feast-and-famine/) [No. 12: Weather](https://thenewinquiry.com/tag/no-12-weather/) [No. 14: Time](https://thenewinquiry.com/tag/no-14-time/) [NYC Community Events](https://thenewinquiry.com/tag/nyc-community-events/) [Palestine](https://thenewinquiry.com/tag/palestine/) [race](https://thenewinquiry.com/tag/race/) [Review](https://thenewinquiry.com/tag/review/) [speculative criticism](https://thenewinquiry.com/tag/speculative-criticism/) [stereohell](https://thenewinquiry.com/tag/stereohell/) [Sunday Reading](https://thenewinquiry.com/tag/sunday-reading/) [Terrifying Robot Update](https://thenewinquiry.com/tag/terrifying-robot-update/) [This Week in Art Crime](https://thenewinquiry.com/tag/this-week-in-art-crime/) [Tidbit](https://thenewinquiry.com/tag/tidbit/) [TNI Magazine](https://thenewinquiry.com/tag/tni-magazine/) [translation](https://thenewinquiry.com/tag/translation/) [un(der)known writers](https://thenewinquiry.com/tag/underknown-writers/) [Un(der)seen Cinema](https://thenewinquiry.com/tag/underseen-cinema/)

## Pages

- [#80463 (no title)](https://thenewinquiry.com/dark-inquiry/)
- [2017](https://thenewinquiry.com/2017-3/)
- [About](https://thenewinquiry.com/about/)
- [About TNI Magazine](https://thenewinquiry.com/about-tni-magazine/)
- [Contact Us](https://thenewinquiry.com/contact-us/)
- [Contributors](https://thenewinquiry.com/contributors/)
- [Feasts Under the Bridge](https://thenewinquiry.com/feasts-under-the-bridge/)
- [Fists Up, Fight Back](https://thenewinquiry.com/fistsup/)
- [Frequently Asked Questions](https://thenewinquiry.com/faq/)
- [Happy Halloween!](https://thenewinquiry.com/happy-halloween/)
- [Manage Subscription](https://thenewinquiry.com/manage-account/)
- [Money Crossword](https://thenewinquiry.com/money-crossword/)
- [Muhammad Ali, We Still Love You](https://thenewinquiry.com/muhammad-ali-we-still-love-you/)
- [Newsletter Subscription Confirmed](https://thenewinquiry.com/newsletter-subscription-confirmed/)
- [Publications](https://thenewinquiry.com/publications/)
    - [Magazines](https://thenewinquiry.com/publications/magazines/)
        - [Subscribe to The New Inquiry Magazine](https://thenewinquiry.com/publications/magazines/subscribe/)
            - [Error](https://thenewinquiry.com/publications/magazines/subscribe/error/)
            - [Process](https://thenewinquiry.com/publications/magazines/subscribe/process/)
            - [Thanks!](https://thenewinquiry.com/publications/magazines/subscribe/thank-you/)
- [Sci-Fi Crime Drama With A Strong Black Lead](https://thenewinquiry.com/sci-fi-crime-drama-with-a-strong-black-lead/)
- [Submit to TNI](https://thenewinquiry.com/submit-to-tni/)
- [Support TNI](https://thenewinquiry.com/donate/)
- [Suppressed Images](https://thenewinquiry.com/suppressed-images/)
- [Tempabout](https://thenewinquiry.com/tempabout/)
- [Terms Of Use](https://thenewinquiry.com/terms-of-use/)
- [Thank You](https://thenewinquiry.com/thank-you-2/)
- [Thank You For Your Support](https://thenewinquiry.com/thank-you-for-your-support/)
- [Thank You!](https://thenewinquiry.com/thank-you/)
- [The Day After The Election I Did Not Go Outside](https://thenewinquiry.com/the-day-after-the-election-i-did-not-go-outside/)
- [TNI Women Test](https://thenewinquiry.com/tni-women-test/)
- [Vol. 1: Precarity](https://thenewinquiry.com/vol-1-precarity/)
- [Vol. 10: Gossip](https://thenewinquiry.com/vol-10-gossip/)
- [Vol. 11: Feast and Famine](https://thenewinquiry.com/vol-11-feast-and-famine/)
- [Vol. 12: Weather](https://thenewinquiry.com/vol-12-weather/)
- [Vol. 13: <3](https://thenewinquiry.com/vol-13/)
- [Vol. 14: Time](https://thenewinquiry.com/vol-14-time/)
- [Vol. 15: Weed](https://thenewinquiry.com/vol-15-weed/)
- [Vol. 16: New World Order](https://thenewinquiry.com/vol-16-new-world-order/)
- [Vol. 17: Games](https://thenewinquiry.com/vol-17-games/)
- [Vol. 18: Family Planning](https://thenewinquiry.com/vol-18-family-planning/)
- [Vol. 19: "Art"](https://thenewinquiry.com/vol-19-art/)
- [Vol. 2: Youth](https://thenewinquiry.com/vol-2-youth/)
- [Vol. 3: Arguing the Web](https://thenewinquiry.com/vol-3-arguing-the-web/)
- [Vol. 4: Beauty](https://thenewinquiry.com/vol-4-beauty/)
- [Vol. 5: Spies](https://thenewinquiry.com/vol-5-spies/)
- [Vol. 6: Game of Drones](https://thenewinquiry.com/vol-6-game-of-drones/)
- [Vol. 7: Cops](https://thenewinquiry.com/vol-7-cops/)
- [Vol. 8: Other Animals](https://thenewinquiry.com/vol-8-other-animals/)
- [Vol. 9: Concept Album](https://thenewinquiry.com/vol-9-concept-album/)

[The New Inquiry is a 501(c)3 organization.](/donate/)

- [Contact](https://thenewinquiry.com/contact-us/)
- [Submit](https://thenewinquiry.com/submit-to-tni/)
- [Donate](https://thenewinquiry.com/donate/)
- [About](https://thenewinquiry.com/about/)
- [Subscribe](https://members.thenewinquiry.com)
- [Manage Subscription](https://thenewinquiry.com/manage-account/)
- [Browse the Archive](https://thenewinquiry.com/category/essays-reviews/)
- [Terms Of Use](https://thenewinquiry.com/terms-of-use/)

- [Facebook](https://www.facebook.com/TheNewInquiry)
- [Twitter](https://twitter.com/newinquiry/)
- [Tumblr](https://thenewinquiry.tumblr.com/)
- [Instagram](https://www.instagram.com/newinquiry/)
- [RSS](/rss)

### Subscribe to Newsletter

Email  

Leave this field empty if you're human: 

![](https://thenewinquiry.com/app/themes/tni/images/head.png)

![facebook_pixel](https://www.facebook.com/tr?id=1292354514219229&ev=PageView&noscript=1&cd[domain]=thenewinquiry.com)