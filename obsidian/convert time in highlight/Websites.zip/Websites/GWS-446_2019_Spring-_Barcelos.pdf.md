---
doc_type: hypothesis-highlights
url: >-
  https://gws.wisc.edu/wp-content/uploads/sites/249/2018/11/GWS-446_2019_Spring-_Barcelos.pdf
---

# GWS-446_2019_Spring-_Barcelos.pdf

## Metadata
- Author: [gws.wisc.edu]()
- Title: GWS-446_2019_Spring-_Barcelos.pdf
- Reference: https://gws.wisc.edu/wp-content/uploads/sites/249/2018/11/GWS-446_2019_Spring-_Barcelos.pdf
- Category: #article

## Page Notes
## Highlights
- The academy is not paradise. But learning is a place where paradise can be created. The classroom,with all its limitations, remains a location of possibility. In that field of possibility we have theopportunity to labour for freedom, to demand of ourselves and our comrades, an openness of mind andheart that allows us to face reality even as we collectively imagine ways to move beyond boundaries, totransgress. This is education as the practice of freedom — [Updated on 2022-09-02 14:28:24](https://hyp.is/vTJcJiq6Ee2HEVfz-3vyoA/gws.wisc.edu/wp-content/uploads/sites/249/2018/11/GWS-446_2019_Spring-_Barcelos.pdf) — Group: #inbox

- This course examines the emergent theoretical field ofqueer of color critique, a mode of analysis grounded in thestruggles and world-making of LGBTQ people of color.Activists, artists, and theorists have mobilized queer of colorcritique to interrogate the intersections of race, gender,sexuality, class, nation, and diaspora as a response to theinherent whiteness of mainstream queer theory andpersistent heterosexism in ethnic studies. We will examinethe development of queer of color critique (primarily in theUnited States) through both academic and activist domains;consider what queer theory has to say about empire,citizenship, prisons, welfare, neoliberalism, and terrorism;and articulate the role of queer of color analysis in a visionfor racial, gender, sexual, and economic justice. — [Updated on 2022-09-02 14:29:07](https://hyp.is/1vTTPCq6Ee2cuS-QRLdhXA/gws.wisc.edu/wp-content/uploads/sites/249/2018/11/GWS-446_2019_Spring-_Barcelos.pdf) — Group: #inbox




