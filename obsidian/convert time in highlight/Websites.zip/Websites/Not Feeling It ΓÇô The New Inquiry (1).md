---
doc_type: hypothesis-highlights
url: 'https://thenewinquiry.com/not-feeling-it/'
---

# Not Feeling It – The New Inquiry

## Metadata
- Author: [thenewinquiry.com]()
- Title: Not Feeling It – The New Inquiry
- Reference: https://thenewinquiry.com/not-feeling-it/
- Category: #article

## Page Notes
## Highlights
- As black feminists like Audre Lorde have pointed out, boundaries are a way to refuse the constant demands for gendered and racialized emotional labor. — [Updated on 2022-09-02 02:01:01](https://hyp.is/VMEeVipSEe2lG785l0BDHg/thenewinquiry.com/not-feeling-it/) — Group: #inbox

- isn’t it cool how sticky and porous emotions are? — [Updated on 2022-09-02 12:37:33](https://hyp.is/QMKEciqrEe2000cZ0R-K8Q/thenewinquiry.com/not-feeling-it/) — Group: #inbox

- In an abolitionist context, something like de-escalation is, in a way, also about feeling less. Because in a moment of heightened conflict, what both sides need is to just like take a second and be like, “Wow. I need to chill. And touch grass.” And one way to de-escalate is actually to reframe the conflict so that it’s less about individual blame, or saying that the pain anyone feels is unreal, and more about how the situation is socially reproduced by structural forces which oppress everyone involved. — [Updated on 2022-09-02 14:18:55](https://hyp.is/ajvXUCq5Ee2VWn9plQhcXQ/thenewinquiry.com/not-feeling-it/) — Group: #inbox

- This reminds me of my “getting in fights with people on Twitter” era lol. I’d tell my enemies, “I’m right,” and they’d just be like, “Why are you so obsessed with me?” Which was embarrassing because it was true. I’m obsessed with you in that I’m giving you so much of my energy. And, in an attention economy, what could be more of a self-own? — [Updated on 2022-09-02 14:21:32](https://hyp.is/x8zAliq5Ee2Bw6NNeFn4Dg/thenewinquiry.com/not-feeling-it/) — Group: #inbox

- When you’re talking about affect, there’s always the temptation to make a universalizing move. Because you want something that speaks to the individual, but is also more generally useful. But this is when it becomes useful to bear in mind Sylvia Wynter, or Denise Ferreira da Silva, whose work analyzes the way universal affect leads to the Enlightenment’s universal “Man.” We don’t want to do that. What we’re trying to do instead is make frameworks that speak deeply as a theory in the flesh, both to us and to those we care about in our communities. So how can we push back against universalism’s portability, which is of course based on racial violence. — [Updated on 2022-09-02 15:35:29](https://hyp.is/HAtSvCrEEe2V6lsJq5TfHw/thenewinquiry.com/not-feeling-it/) — Group: #inbox




