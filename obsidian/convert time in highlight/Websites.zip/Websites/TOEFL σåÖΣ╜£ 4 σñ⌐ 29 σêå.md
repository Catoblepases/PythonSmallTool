---
url: http://mp.weixin.qq.com/s?__biz=MzI3ODQ1MzQ0Mg==&mid=2247483817&idx=1&sn=a32d64d5d097d1c70e773bf24006f9ec&chksm=eb578c04dc200512bc5e9bba87a030b076a66cd2bb8ec90a27fa54ad41119517ac40e42eda86#rd
readlater:
  id: "1536324197"
  provider: instapaper
  synchtime: 1701965978161
---
             

# TOEFL写作4天29分

Lin [MissWriting](javascript:void(0);)

**MissWriting** 

Weixin ID gh_1d54c0ab758f

About Feature 写作是一项燃烧生命的事业 || Writing and sharing pave the way for a brighter life

_Posted on_

收录于合集

未经授权请勿转载，尊重劳动和创造的人们是幸福的；

当然，欢迎大家转到朋友圈，传播劳动和创造的人们也是幸福的。

  

去年8月的时候，MissWriting恰好考了一次托福。因时间并不宽裕，备考时间仅为两周，其中写作仅用最后4天准备，然写作部分取得了29分。虽有1分遗憾，但想到我短时间内突击，也就释然了。

最近颇多考托大军问询，在此分享几点应试型写作心得。当然，非常建议大家**时间充裕的话踏踏实实拿出长时间进行ETS下属的TOEFL和GRE的写作准备**，对于素材积累和功底练习都是全方位的提高。

  

其中，托福写作Writing部分主要考察的是听力、同义改写和套用模板。综合写作的听力部分和同义改写暂且按下不表，今日先谈谈**独立写作**中最简单的**套用模板**。

  

**第一，任何一项写作要考虑的第一问题是读者受众，即audience。**

例如，托福写作的audience即以英语为母语的阅卷者，而四六级的阅卷官即为高校英语专业的老师或研究生。

**第二，基于此，我们可以把准备步骤拆解如下👇**

**步骤1：选取【英美通用】事例。**

请注意，不要讲中国的例子，比如有一道题目问，“请描述你的国家最近发生的大事”，有同学回来告诉我，他讲的是王宝强离婚。

没有极强的语言能力和逻辑能力，是很难用外语解释清楚本国发生的事情的。想象下，印度友人跟你讲他们的土邦国王离世，没有背景烘托的情况下我们很容易云里雾里摸不着头脑；这和把“王宝强离婚”写在托福写作中讲给英美的native speaker是一个道理。

个人认为，一个**优秀的【英美通用】事例**应当满足两点：

**1）个人熟悉或喜欢的领域。**例如我的专业是英美文学，则对作家更为熟悉，可选择Virginia Woolf等；若是平时爱好体育，则可以考虑如科比的奋斗历程等。

**2）能够从多角度阐释各种问题，参考我国的司马迁同志。**经济、政治、艺术、商业领域各3个即可，不超过15个，多了会背不下来的。另外温馨提示，环境、校园生活、食品安全等机经中出现的较专业化或生活化的，请依据个人考试时间和情况自行积累。

**步骤2：参考维基百科，用自己的语言改写此人相关示例，并背诵默写。**

请注意，一定要自己先改写！先改写！先改写！重要的事情说三遍。其一是因为原封不动地照搬容易雷同，其二是不是自己写出来的东西背诵极其困难。。。 

  

**步骤3：检索历年考题的分类整理。**

这个很容易，网上最不缺的就是托福机经。

  

**步骤4：列提纲→写部分→写全文**

1）选取40道题目，限时2分钟列出所需素材事例；

2）选取20道题目，写出开头、每段的段首、结尾；

3）选取5道题目，限时写出全文并修改。

  

下面，以我自己的备考为例，走一遍这个流程。

**步骤1：选取【英美通用】事例。**

我分类整理了自己的榜单👇  

**商业科技**

Elon Musk，Steve Jobs，Bill Gates

**政治**

Franklin Roosevelt，Barack Obama，Sir Winston Churchill

**经济**

Adam Smith，Johan Keynes

**文化艺术**

Leonard da Vinci，Virginia Woolf，Plato

**体育娱乐**

The Big Bang Theory，House of Cards，

Harry Potter，

Phelps，Natalie Portman

  

**步骤2：改写、背诵和默写。**

参考维基百科，用自己的语言改写此人相关示例，并背诵默写。改写时注意保留一些精彩的句式和词法。以乔布斯为例，可拓展如下👇  

**个人简介**

Steve Jobs, widely recognized as a **pioneer** of the microcomputer revolution of the 1970s and 1980s, was **an American information technology entrepreneur and inventor**. He was the co-founder, chairman, and CEO of Apple Inc. Undoubtedly, he was **a creative entrepreneur whose passion for perfection and ferocious drive revolutionized six industries**: personal computers, animated movies, music, phones, tablet computing, and digital publishing.

**上学期间修字体课（处处积累处处惊喜）&辍学（学校不是唯一出路）**

At the age of 19, Jobs enrolled at Reed College, which was an expensive college his parents could ill afford. Brennan, his best friend, did not have plans to attend college, and **was supportive of** Jobs when he told her he planned to drop out of Reed because he did not want to spend his parents’ money on it. Then Jobs dropped out of Reed but continued to attend by auditing classes, including a course on calligraphy. In a 2005 commencement speech for Stanford University, Jobs states that during this period, he slept on the floor in friends’ dorm rooms, returned Coke bottles for food money, and got weekly free meals at the local temple. In that same speech, Jobs said: “**If I had never dropped in on that single calligraphy course in college, the Mac would have never had multiple typefaces or proportionally spaced fonts.**”

**苹果发布会（技术改变世界）**

In 2007, Apple **entered the cellular phone business with the introduction of the iPhone,** a multi-touch display cell phone, which also included the features of an iPod and, with its own mobile browser, revolutionized the mobile browsing scene. While nurturing innovation, Jobs also reminded his employees that **“real artists ship”**. The presentation show of iPhone received high praise from the audience and Jobs’ simple T-shirt and jeans has also integrated with iPhone’s concise design.

**离世（身体的重要性&工作生活的平衡）**

Jobs was diagnosed with a pancreatic neuroendocrine tumor in 2003 and **died of respiratory arrest** related to the tumor on October 5, 2011.

  

**步骤3：检索历年考题的分类整理。**

此处省略一万字，请自行脑补。  

  

**步骤4：列提纲→写部分→写全文**

以“社会关系”下这一类曾考过的话题为例👇  

**politician leader需要good communication skills？**

奥巴马、罗斯福（围炉谈话）、丘吉尔（站前激励）

**名人需要更多隐私空间吗？**

菲尔普斯（吸毒事件）、Portman

**artists和political leader谁贡献更多？**

political leader，如奥巴马、罗斯福、丘吉尔

  

因篇幅所限，部分写作和全文写作就不在此列出，大家写出后记得要找能够hold住的人帮忙批改。

  

虽然个人从来不赞成写作速成法，不过，秉持着性价比最高的原则，还是应当用最短的时间获取最大的收益。  

  

如果你热爱英语写作，并希望借此机会不断提高，当然最佳；如若不然，用最短的时间收益最大化，之后的时间就可以投身于更多你所热爱的事业，当然更佳。

祝大家考有所成，圆满和ETS分手！

  

  

END

  

**MissWriting**

写作是一项燃烧生命的事业  

Writing and Sharing path the way for a brighter life

  

  

预览时标签不可点

Scan to Follow

轻触阅读原文

 

继续滑动看下一个

[Got It](javascript:;)

 

 Scan with Weixin to  
use this Mini Program

[Cancel](javascript:void(0);) [Allow](javascript:void(0);)

[Cancel](javascript:void(0);) [Allow](javascript:void(0);)

 : ， .   Video Mini Program Like ，轻点两下取消赞 Wow ，轻点两下取消在看