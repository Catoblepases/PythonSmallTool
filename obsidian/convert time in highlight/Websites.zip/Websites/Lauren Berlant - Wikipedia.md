---
url: https://en.wikipedia.org/wiki/Lauren_Berlant
readlater:
  id: "1534293796"
  provider: instapaper
  synchtime: 1701965973724
---
[Jump to content](#bodyContent)

 Main menu

Main menu

move to sidebar hide

Navigation

- [Main page](/wiki/Main_Page "Visit the main page [z]")
- [Contents](/wiki/Wikipedia:Contents "Guides to browsing Wikipedia")
- [Current events](/wiki/Portal:Current_events "Articles related to current events")
- [Random article](/wiki/Special:Random "Visit a randomly selected article [x]")
- [About Wikipedia](/wiki/Wikipedia:About "Learn about Wikipedia and how it works")
- [Contact us](//en.wikipedia.org/wiki/Wikipedia:Contact_us "How to contact Wikipedia")
- [Donate](https://donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikipedia.org&uselang=en "Support us by donating to the Wikimedia Foundation")

Contribute

- [Help](/wiki/Help:Contents "Guidance on how to use and edit Wikipedia")
- [Learn to edit](/wiki/Help:Introduction "Learn how to edit Wikipedia")
- [Community portal](/wiki/Wikipedia:Community_portal "The hub for editors")
- [Recent changes](/wiki/Special:RecentChanges "A list of recent changes to Wikipedia [r]")
- [Upload file](/wiki/Wikipedia:File_upload_wizard "Add images or other media for use on Wikipedia")

Languages

Language links are at the top of the page across from the title.

  [![](/static/images/icons/wikipedia.png) ![Wikipedia](/static/images/mobile/copyright/wikipedia-wordmark-en.svg) ![The Free Encyclopedia](/static/images/mobile/copyright/wikipedia-tagline-en.svg)](/wiki/Main_Page)

[Search](/wiki/Special:Search "Search Wikipedia [f]")

Search

- [Create account](/w/index.php?title=Special:CreateAccount&returnto=Lauren+Berlant "You are encouraged to create an account and log in; however, it is not mandatory")
- [Log in](/w/index.php?title=Special:UserLogin&returnto=Lauren+Berlant "You're encouraged to log in; however, it's not mandatory. [o]")

 Personal tools

- [Create account](/w/index.php?title=Special:CreateAccount&returnto=Lauren+Berlant "You are encouraged to create an account and log in; however, it is not mandatory")
- [Log in](/w/index.php?title=Special:UserLogin&returnto=Lauren+Berlant "You're encouraged to log in; however, it's not mandatory. [o]")

Pages for logged out editors [learn more](/wiki/Help:Introduction)

- [Contributions](/wiki/Special:MyContributions "A list of edits made from this IP address [y]")
- [Talk](/wiki/Special:MyTalk "Discussion about edits from this IP address [n]")

## Contents

move to sidebar hide

- [
    
    (Top)
    
    ](#)
- [
    
    1Early life and education
    
    ](#Early_life_and_education)
    
- [
    
    2Career
    
    ](#Career)
    
- [
    
    3Works
    
    ](#Works)
    
- [
    
    4Death
    
    ](#Death)
    
- [
    
    5Bibliography
    
    ](#Bibliography)Toggle Bibliography subsection
    - [
        
        5.1Books
        
        ](#Books)
        
    - [
        
        5.2Edited collections
        
        ](#Edited_collections)
        
- [
    
    6See also
    
    ](#See_also)
    
- [
    
    7Notes
    
    ](#Notes)
    
- [
    
    8References
    
    ](#References)
    
- [
    
    9External links
    
    ](#External_links)
    

 Toggle the table of contents

# Lauren Berlant

 8 languages

- [العربية](https://ar.wikipedia.org/wiki/%D9%84%D9%88%D8%B1%D9%8A%D9%86_%D8%A8%D8%B1%D9%84%D9%86%D8%AA "لورين برلنت – Arabic")
- [Български](https://bg.wikipedia.org/wiki/%D0%9B%D0%BE%D1%80%D1%8A%D0%BD_%D0%91%D0%B5%D1%80%D0%BB%D0%B0%D0%BD%D1%82 "Лорън Берлант – Bulgarian")
- [Català](https://ca.wikipedia.org/wiki/Lauren_Berlant "Lauren Berlant – Catalan")
- [Deutsch](https://de.wikipedia.org/wiki/Lauren_Berlant "Lauren Berlant – German")
- [Français](https://fr.wikipedia.org/wiki/Lauren_Berlant "Lauren Berlant – French")
- [مصرى](https://arz.wikipedia.org/wiki/%D9%84%D9%88%D8%B1%D9%8A%D9%86_%D8%A8%D8%B1%D9%84%D9%86%D8%AA "لورين برلنت – Egyptian Arabic")
- [Volapük](https://vo.wikipedia.org/wiki/Lauren_Berlant "Lauren Berlant – Volapük")
- [中文](https://zh.wikipedia.org/wiki/%E5%8A%B3%E4%BC%A6%C2%B7%E8%B4%9D%E5%85%B0%E7%89%B9 "劳伦·贝兰特 – Chinese")

[Edit links](https://www.wikidata.org/wiki/Special:EntityPage/Q12237573#sitelinks-wikipedia "Edit interlanguage links")

- [Article](/wiki/Lauren_Berlant "View the content page [c]")
- [Talk](/wiki/Talk:Lauren_Berlant "Discuss improvements to the content page [t]")

 English

- [Read](/wiki/Lauren_Berlant)
- [Edit](/w/index.php?title=Lauren_Berlant&action=edit "Edit this page [e]")
- [View history](/w/index.php?title=Lauren_Berlant&action=history "Past revisions of this page [h]")

 Tools

Tools

move to sidebar hide

Actions

- [Read](/wiki/Lauren_Berlant)
- [Edit](/w/index.php?title=Lauren_Berlant&action=edit "Edit this page [e]")
- [View history](/w/index.php?title=Lauren_Berlant&action=history)

General

- [What links here](/wiki/Special:WhatLinksHere/Lauren_Berlant "List of all English Wikipedia pages containing links to this page [j]")
- [Related changes](/wiki/Special:RecentChangesLinked/Lauren_Berlant "Recent changes in pages linked from this page [k]")
- [Upload file](/wiki/Wikipedia:File_Upload_Wizard "Upload files [u]")
- [Special pages](/wiki/Special:SpecialPages "A list of all special pages [q]")
- [Permanent link](/w/index.php?title=Lauren_Berlant&oldid=1187106896 "Permanent link to this revision of this page")
- [Page information](/w/index.php?title=Lauren_Berlant&action=info "More information about this page")
- [Cite this page](/w/index.php?title=Special:CiteThisPage&page=Lauren_Berlant&id=1187106896&wpFormIdentifier=titleform "Information on how to cite this page")
- [Get shortened URL](/w/index.php?title=Special:UrlShortener&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FLauren_Berlant)
- [Wikidata item](https://www.wikidata.org/wiki/Special:EntityPage/Q12237573 "Structured data on this page hosted by Wikidata [g]")

Print/export

- [Download as PDF](/w/index.php?title=Special:DownloadAsPdf&page=Lauren_Berlant&action=show-download-screen "Download this page as a PDF file")
- [Printable version](/w/index.php?title=Lauren_Berlant&printable=yes "Printable version of this page [p]")

In other projects

- [Wikimedia Commons](https://commons.wikimedia.org/wiki/Category:Lauren_Berlant)

From Wikipedia, the free encyclopedia

American academic and author (1957–2021)

|Lauren Berlant|   |
|---|---|
|Born|October 31, 1957 (1957-10-31)  <br><br>[Philadelphia, Pennsylvania](/wiki/Philadelphia,_Pennsylvania "Philadelphia, Pennsylvania"), U.S.|
|Died|June 28, 2021(2021-06-28) (aged 63)  <br><br>[Chicago, Illinois](/wiki/Chicago,_Illinois "Chicago, Illinois"), U.S.|
|Known for|- [Queer theory](/wiki/Queer_theory "Queer theory")<br>- [heteronormativity](/wiki/Heteronormativity "Heteronormativity")<br>- [affect theory](/wiki/Affect_theory "Affect theory")|
|Awards|[Guggenheim Fellowship](/wiki/Guggenheim_Fellowship "Guggenheim Fellowship")|
||   |
|Academic background|   |
|Education|- [Oberlin College](/wiki/Oberlin_College "Oberlin College") ([BA](/wiki/Bachelor_of_Arts "Bachelor of Arts"))<br>- [Cornell University](/wiki/Cornell_University "Cornell University") ([MA](/wiki/Master_of_Arts "Master of Arts"), [PhD](/wiki/Doctor_of_Philosophy "Doctor of Philosophy"))|
|Academic work|   |
|Institutions|[University of Chicago](/wiki/University_of_Chicago "University of Chicago")|
||   |

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/32/Scholia_logo.svg/40px-Scholia_logo.svg.png)

[Scholia](https://www.wikidata.org/wiki/Wikidata:Scholia "d:Wikidata:Scholia") has a profile for [**Lauren Berlant (Q12237573)**](https://iw.toolforge.org/scholia/Q12237573 "toolforge:scholia/Q12237573").

**Lauren Gail Berlant**[[1]](#cite_note-:6-1) (October 31, 1957 – June 28, 2021) was an American scholar, [cultural theorist](/wiki/Culture_theory "Culture theory"), and author who is regarded as "one of the most esteemed and influential literary and cultural critics in the United States."[[2]](#cite_note-2)[[3]](#cite_note-3) Berlant was the [George M. Pullman](/wiki/George_M._Pullman "George M. Pullman") Distinguished Service Professor of English at the [University of Chicago](/wiki/University_of_Chicago "University of Chicago"), where they[[a]](#cite_note-4) taught from 1984 until 2021.[[4]](#cite_note-:0-5) Berlant wrote and taught issues of intimacy and belonging in [popular culture](/wiki/Popular_culture "Popular culture"), in relation to the history and fantasy of [citizenship](/wiki/Citizenship "Citizenship").[[5]](#cite_note-6)

Berlant wrote on [public spheres](/wiki/Public_sphere "Public sphere") as they affect worlds, where [affect](/wiki/Affect_theory "Affect theory") and emotion lead the way for belonging ahead of the modes of rational or deliberative thought. These attach strangers to each other and shape the terms of the state-civil society relation.

## Early life and education[[edit](/w/index.php?title=Lauren_Berlant&action=edit&section=1 "Edit section: Early life and education")]

Berlant was born on October 31, 1957, in [Philadelphia, Pennsylvania](/wiki/Philadelphia,_Pennsylvania "Philadelphia, Pennsylvania").[[1]](#cite_note-:6-1)[[6]](#cite_note-:2-7) They graduated with a BA in English from [Oberlin College](/wiki/Oberlin_College "Oberlin College") in 1979,[[7]](#cite_note-8) then an MA from [Cornell University](/wiki/Cornell_University "Cornell University") in 1983,[[6]](#cite_note-:2-7) and finally a PhD from Cornell in 1985,[[8]](#cite_note-:1-9) after they had already begun teaching at the University of Chicago.[[6]](#cite_note-:2-7) (They said student loans obliged them to continue straight through school without a break that would have triggered loan repayment.)[[6]](#cite_note-:2-7) Berlant's dissertation was titled, _Executing The Love Plot: Hawthorne and The Romance of Power_ (1985).[[8]](#cite_note-:1-9)

## Career[[edit](/w/index.php?title=Lauren_Berlant&action=edit&section=2 "Edit section: Career")]

Berlant taught at the [University of Chicago](/wiki/University_of_Chicago "University of Chicago") from 1984 to 2021, becoming the George M. Pullman Distinguished Service Professor of English.[[4]](#cite_note-:0-5) The university awarded them a Quantrell Award for Excellence in Undergraduate Teaching (1989), a Faculty Award for Excellence in Graduate Teaching and Mentoring (2005), and the Norman Maclean Faculty Award (2019).[[9]](#cite_note-:5-10)

Berlant's other honors included a [Guggenheim Fellowship](/wiki/Guggenheim_Fellowship "Guggenheim Fellowship") and, for their book _Cruel Optimism_, the [René Wellek](/wiki/Ren%C3%A9_Wellek "René Wellek") Prize of the American Comparative Literature Association[[6]](#cite_note-:2-7) and the Alan Bray Memorial Book Award from the [Modern Language Association](/wiki/Modern_Language_Association "Modern Language Association") (MLA) for the best book in queer studies in literature or cultural studies.[[10]](#cite_note-11) Berlant was elected to the [American Academy of Arts and Sciences](/wiki/American_Academy_of_Arts_and_Sciences "American Academy of Arts and Sciences") in 2018.[[6]](#cite_note-:2-7)

Berlant was a founding member of Feel Tank Chicago in 2002, a play on [think tank](/wiki/Think_tank "Think tank").[[4]](#cite_note-:0-5) They worked with many journals, including (as editor) _Critical Inquiry_.[[6]](#cite_note-:2-7) They also edited Duke University Press's Theory Q series along with [Lee Edelman](/wiki/Lee_Edelman "Lee Edelman"), [Benjamin Kahan](/w/index.php?title=Benjamin_Kahan&action=edit&redlink=1 "Benjamin Kahan (page does not exist)"), and [Christina Sharpe](/wiki/Christina_Sharpe "Christina Sharpe").

## Works[[edit](/w/index.php?title=Lauren_Berlant&action=edit&section=3 "Edit section: Works")]

Berlant was the author of a national sentimentality trilogy beginning with _The Anatomy of National Fantasy: Hawthorne, Utopia, and Everyday Life_ (University of Chicago Press, 1991). Based on their dissertation,[[6]](#cite_note-:2-7) the book looks at the formation of national identity as the relations between modes of belonging mediated by the state and law; by aesthetics, especially genre; and by the everyday life of social relations, drawing on [Nathaniel Hawthorne](/wiki/Nathaniel_Hawthorne "Nathaniel Hawthorne")'s work to illustrate these operations.[[11]](#cite_note-12)

_The Queen of America Goes to Washington City: Essays on Sex and Citizenship_—the title essay winning the 1993 Norman Foerster Award for best essay of the year in American literature[[12]](#cite_note-13)—introduced the idea of the "intimate public sphere" and looks at the production of politics and publicness since the Reagan era by way of the circulation of the personal, the sexual, and the intimate.[[13]](#cite_note-:3-14) In his review, [José Muñoz](/wiki/Jos%C3%A9_Esteban_Mu%C3%B1oz "José Esteban Muñoz") described it as both [intersectional](/wiki/Intersectionality "Intersectionality"), following [Kimberlé Crenshaw](/wiki/Kimberl%C3%A9_Crenshaw "Kimberlé Crenshaw"), and "post-[Habermassian](/wiki/J%C3%BCrgen_Habermas "Jürgen Habermas")", in the vein of work by [Nancy Fraser](/wiki/Nancy_Fraser "Nancy Fraser") and Berlant's frequent collaborator [Michael Warner](/wiki/Michael_Warner "Michael Warner").[[13]](#cite_note-:3-14) Berlant's third book (though second in the trilogy),[[14]](#cite_note-:4-15) _The Female Complaint: On the Unfinished Business of Sentimentality in American Culture_ was published by Duke University Press in 2008. The project initially began in the 1980s when Berlant noticed striking similarities in writing by [Erma Bombeck](/wiki/Erma_Bombeck "Erma Bombeck") and [Fanny Fern](/wiki/Fanny_Fern "Fanny Fern"), who skewered married life for women in nearly identical ways despite being separated by 150 years.[[15]](#cite_note-16) Berlant pursued this mass cultural phenomenon of "women's culture" as an originating site of “intimate publics", threading the everyday institutions of intimacy, mass society, and, more distantly and ambivalently, politics through fantasies rather than ideology.[[14]](#cite_note-:4-15) Berlant took up this project by examining especially melodramas and their remade movies in the first part of the twentieth century, such as [_Show Boat_](/wiki/Show_Boat_(1951_film) "Show Boat (1951 film)"), [_Imitation of Life_](/wiki/Imitation_of_Life_(1959_film) "Imitation of Life (1959 film)"), and _[Uncle Tom's Cabin](/wiki/Uncle_Tom%27s_Cabin_(1965_film) "Uncle Tom's Cabin (1965 film)")_.[[14]](#cite_note-:4-15)

Berlant's 2011 book, _Cruel Optimism_ (Duke University Press) works its way across the U.S. and Europe to assess the level of contemporary crisis as [neoliberalism](/wiki/Neoliberalism "Neoliberalism") wears away the fantasies of upward mobility associated with the liberal state.[[16]](#cite_note-17) Cruel optimism manifests as a relational dynamic in which individuals create attachment as "clusters of promises" toward desired object-ideas even when they inhibit the conditions for flourishing and fulfilling such promises. Maintaining attachments that sustain the good life fantasy, no matter how injurious or cruel these attachments may be, allows people to make it through day-to-day life when the day-to-day has become unlivable.[[17]](#cite_note-acReview-18) Elaborating on the specific dynamics of cruel optimism, Berlant emphasizes and maintains that it is not the object itself, but rather the relationship:

> A relation of cruel optimism is a double-bind in which your attachment to an object sustains you in life at the same time as that object is actually a threat to your flourishing. So you can't say that there are objects that have the quality of cruelty or not cruelty, it's how you have the relationship to them. Like it might be that being in a couple is not a relation of cruel optimism for you, because being in a couple actually makes you feel like you have a grounding in the world, whereas for other people, being in a couple might be, on the one hand, a relief from loneliness, and on the other hand, the overpresence of one person who has to bear the burden of satisfying all your needs. So it's not the object that's the problem, but how we learn to be in relation.[[18]](#cite_note-19)

An emphasis on the "present", which Berlant describes as structured through "crisis ordinariness", turns to affect and aesthetics as a way of apprehending these crises. Berlant suggests that it becomes possible to recognize that certain "genres" are no longer sustainable in the present and that new emergent aesthetic forms are taking hold that allow us to recognize modes of living not rooted in normative good life fantasies.[[17]](#cite_note-acReview-18) Discussing crisis ordinariness, Berlant described it as their way "of talking about traumas of the social that are lived through collectively and that transform the sensorium to a heightened perceptiveness about the unfolding of the historical, and sometimes historic, moment (and sometimes publics organized around those senses, when experienced collectively)."[[19]](#cite_note-20)

In 2019, Berlant published _The Hundreds_ with Kathleen Stewart, a collection of brief writing (a hundred words or a multiple of a hundred words) on ordinary encounters, applying affect theory to moments of unexamined daily life.[[4]](#cite_note-:0-5) In _[The New Yorker](/wiki/The_New_Yorker "The New Yorker")_, [Hua Hsu](/wiki/Hua_Hsu "Hua Hsu") said the book "calls to mind the adventurous, hybrid style of [Fred Moten](/wiki/Fred_Moten "Fred Moten") (the book includes a brief poem by him), [Maggie Nelson](/wiki/Maggie_Nelson "Maggie Nelson"), or [Claudia Rankine](/wiki/Claudia_Rankine "Claudia Rankine"), all of whom bend available literary forms into workable vessels for new ideas."[[4]](#cite_note-:0-5)

Berlant has edited books on _Compassion_ (2004) and _Intimacy_ (2001), which are interlinked with their seminal work in feminist and [queer theory](/wiki/Queer_theory "Queer theory") in essays like "What Does Queer Theory Teach Us About X?" (with Michael Warner, 1995),[[20]](#cite_note-21) "Sex in Public" (with Michael Warner, 1998),[[21]](#cite_note-22) _Our Monica, Ourselves: Clinton and the Affairs of State_ (edited with [Lisa Duggan](/wiki/Lisa_Duggan "Lisa Duggan"), 2001),[[22]](#cite_note-23) and _Venus Inferred_ (with photographer [Laura Letinsky](/wiki/Laura_Letinsky "Laura Letinsky"), 2001).[[23]](#cite_note-24)

## Death[[edit](/w/index.php?title=Lauren_Berlant&action=edit&section=4 "Edit section: Death")]

Berlant died of [cancer](/wiki/Cancer "Cancer") in a Chicago hospice facility on June 28, 2021, at age 63.[[1]](#cite_note-:6-1)[[6]](#cite_note-:2-7)[[24]](#cite_note-25) They are survived by their partner Ian Horswill.[[9]](#cite_note-:5-10)

Berlant's papers are held at the Feminist Theory Archive of the [Pembroke Center for Teaching and Research on Women](/wiki/Pembroke_Center_for_Teaching_and_Research_on_Women "Pembroke Center for Teaching and Research on Women") at [Brown University](/wiki/Brown_University "Brown University"). Berlant began donating them in 2014.[[25]](#cite_note-26)

## Bibliography[[edit](/w/index.php?title=Lauren_Berlant&action=edit&section=5 "Edit section: Bibliography")]

### Books[[edit](/w/index.php?title=Lauren_Berlant&action=edit&section=6 "Edit section: Books")]

- Berlant, Lauren (1991). _The Anatomy of National Fantasy: Hawthorne, Utopia, and Everyday Life_. University of Chicago Press. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-0-226-04377-7](/wiki/Special:BookSources/978-0-226-04377-7 "Special:BookSources/978-0-226-04377-7").
- — (1997). _The Queen of America Goes to Washington City: Essays on Sex and Citizenship_. Duke University Press. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-0-8223-1931-3](/wiki/Special:BookSources/978-0-8223-1931-3 "Special:BookSources/978-0-8223-1931-3").
- —; Letinsky, Laura (2000). _Venus Inferred_. University of Chicago Press. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-0-226-47345-1](/wiki/Special:BookSources/978-0-226-47345-1 "Special:BookSources/978-0-226-47345-1").
- — (2008). _The Female Complaint: The Unfinished Business of Sentimentality in American Culture_. Duke University Press. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-0-8223-8916-3](/wiki/Special:BookSources/978-0-8223-8916-3 "Special:BookSources/978-0-8223-8916-3").
- — (2011). _Cruel Optimism_. Duke University Press. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-0-8223-5111-5](/wiki/Special:BookSources/978-0-8223-5111-5 "Special:BookSources/978-0-8223-5111-5"). 2011 René Wellek Prize, American Comparative Literature Association
- — (2012). _Desire/Love_. Punctum Books. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-0-615-68687-5](/wiki/Special:BookSources/978-0-615-68687-5 "Special:BookSources/978-0-615-68687-5").
- —; Edelman, Lee (2013). _Sex, or the Unbearable_. Duke University Press. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-0-8223-7706-1](/wiki/Special:BookSources/978-0-8223-7706-1 "Special:BookSources/978-0-8223-7706-1").
- —; Stewart, Kathleen (February 22, 2019). _The Hundreds_. Duke University Press. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-1-4780-0183-6](/wiki/Special:BookSources/978-1-4780-0183-6 "Special:BookSources/978-1-4780-0183-6").
- Berlant, Lauren (2022). _On the Inconvenience of Other People_. Duke University Press. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-1-4780-1845-2](/wiki/Special:BookSources/978-1-4780-1845-2 "Special:BookSources/978-1-4780-1845-2").

### Edited collections[[edit](/w/index.php?title=Lauren_Berlant&action=edit&section=7 "Edit section: Edited collections")]

- Berlant, Lauren, ed. (1998). _Intimacy_. University of Chicago Press. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [9780226384436](/wiki/Special:BookSources/9780226384436 "Special:BookSources/9780226384436").
- —; Duggan, Lisa, eds. (2001). _Our Monica, Ourselves: The Clinton Affair and the National Interest_. NYU Press. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-0-8147-9864-5](/wiki/Special:BookSources/978-0-8147-9864-5 "Special:BookSources/978-0-8147-9864-5").
- —, ed. (2004). _Compassion: The Culture and Politics of an Emotion_. Routledge. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-0-4159-7052-5](/wiki/Special:BookSources/978-0-4159-7052-5 "Special:BookSources/978-0-4159-7052-5").
- —, ed. (2019). _Reading Sedgwick_. Duke University Press. [ISBN](/wiki/ISBN_(identifier) "ISBN (identifier)") [978-1-4780-0533-9](/wiki/Special:BookSources/978-1-4780-0533-9 "Special:BookSources/978-1-4780-0533-9").

## See also[[edit](/w/index.php?title=Lauren_Berlant&action=edit&section=8 "Edit section: See also")]

- [Achille Mbembe](/wiki/Achille_Mbembe "Achille Mbembe")
- [Jasbir Puar](/wiki/Jasbir_Puar "Jasbir Puar")
- [Necropolitics](/wiki/Necropolitics "Necropolitics")

## Notes[[edit](/w/index.php?title=Lauren_Berlant&action=edit&section=9 "Edit section: Notes")]

1. **[^](#cite_ref-4)** Berlant used she/her [pronouns](/wiki/Preferred_gender_pronoun "Preferred gender pronoun") in personal life but [they/them](/wiki/Singular_they "Singular they") professionally. This article uses they/them accordingly.[[1]](#cite_note-:6-1)

## References[[edit](/w/index.php?title=Lauren_Berlant&action=edit&section=10 "Edit section: References")]

1. ^ [_**a**_](#cite_ref-:6_1-0) [_**b**_](#cite_ref-:6_1-1) [_**c**_](#cite_ref-:6_1-2) [_**d**_](#cite_ref-:6_1-3) Traub, Alex (July 3, 2021). ["Lauren Berlant, Critic of the American Dream, Is Dead at 63"](https://www.nytimes.com/2021/07/03/books/lauren-berlant-dead.html). _The New York Times_. [ISSN](/wiki/ISSN_(identifier) "ISSN (identifier)") [0362-4331](https://www.worldcat.org/issn/0362-4331). Retrieved July 4, 2021.
2. **[^](#cite_ref-2)** Butler, Judith; Doherty, Maggie; Chaudhary, Ajay Singh; Winant, Gabriel (July 8, 2021). ["'What Would It Mean to Think That Thought?': The Era of Lauren Berlant"](https://www.thenation.com/article/culture/lauren-berlant-obituary/). [ISSN](/wiki/ISSN_(identifier) "ISSN (identifier)") [0027-8378](https://www.worldcat.org/issn/0027-8378). Retrieved October 25, 2022. The death of Lauren Berlant, one of the most esteemed and influential literary and cultural critics in the United States, has been met with a keen sense of loss through the academy.
3. **[^](#cite_ref-3)** Patterson, Sara. ["Lauren Berlant wins MLA's lifetime achievement award | University of Chicago News"](https://news.uchicago.edu/story/two-uchicago-scholars-be-honored-modern-language-association). _news.uchicago.edu_. Retrieved October 25, 2022. "Lauren Berlant is one of the most influential scholars of the 21st century."
4. ^ [_**a**_](#cite_ref-:0_5-0) [_**b**_](#cite_ref-:0_5-1) [_**c**_](#cite_ref-:0_5-2) [_**d**_](#cite_ref-:0_5-3) [_**e**_](#cite_ref-:0_5-4) Hsu, Hua (March 25, 2019). ["Affect Theory and the New Age of Anxiety"](https://www.newyorker.com/magazine/2019/03/25/affect-theory-and-the-new-age-of-anxiety). _The New Yorker_. [Archived](https://web.archive.org/web/20210629185146/https://www.newyorker.com/magazine/2019/03/25/affect-theory-and-the-new-age-of-anxiety) from the original on June 29, 2021. Retrieved June 28, 2021.
5. **[^](#cite_ref-6)** ["Big Brains podcast: Why Chasing The Good Life Is Holding Us Back, With Lauren Berlant"](https://news.uchicago.edu/podcasts/big-brains/why-chasing-good-life-holding-us-back-lauren-berlant). _news.uchicago.edu_. [Archived](https://web.archive.org/web/20210629154353/https://news.uchicago.edu/podcasts/big-brains/why-chasing-good-life-holding-us-back-lauren-berlant) from the original on June 29, 2021. Retrieved June 28, 2021.
6. ^ [_**a**_](#cite_ref-:2_7-0) [_**b**_](#cite_ref-:2_7-1) [_**c**_](#cite_ref-:2_7-2) [_**d**_](#cite_ref-:2_7-3) [_**e**_](#cite_ref-:2_7-4) [_**f**_](#cite_ref-:2_7-5) [_**g**_](#cite_ref-:2_7-6) [_**h**_](#cite_ref-:2_7-7) [_**i**_](#cite_ref-:2_7-8) ["Lauren Berlant (1957–2021)"](https://www.artforum.com/news/lauren-berlant-1957-2021-86157). _ArtForum_. June 28, 2021. [Archived](https://web.archive.org/web/20210629000557/https://www.artforum.com/news/lauren-berlant-1957-2021-86157) from the original on June 29, 2021. Retrieved June 29, 2021.
7. **[^](#cite_ref-8)** Carnig, Jennifer (June 9, 2005). ["Lauren Berlant, Professor in English Language & Literature and the Committee on African and African-American Studies"](http://chronicle.uchicago.edu/050609/fta-berlant.shtml). _the University of Chicago Chronicle_. [Archived](https://web.archive.org/web/20210505205952/http://chronicle.uchicago.edu/050609/fta-berlant.shtml) from the original on May 5, 2021. Retrieved June 28, 2021.
8. ^ [_**a**_](#cite_ref-:1_9-0) [_**b**_](#cite_ref-:1_9-1) Pollock, Beth Ruby (1988). [_The Representation of Utopia: Hawthorne and the Female Medium_](https://books.google.com/books?id=xeBGAQAAMAAJ). University of California, Berkeley. [Archived](https://web.archive.org/web/20210628192937/https://books.google.com/books?id=xeBGAQAAMAAJ&newbks=0) from the original on June 28, 2021. Retrieved June 28, 2021.
9. ^ [_**a**_](#cite_ref-:5_10-0) [_**b**_](#cite_ref-:5_10-1) Patterson, Sara (June 28, 2021). ["Lauren Berlant, preeminent literary scholar and cultural theorist, 1957–2021"](https://news.uchicago.edu/story/lauren-berlant-preeminent-literary-scholar-and-cultural-theorist-1957-2021). _University of Chicago News_. [Archived](https://web.archive.org/web/20210629163642/https://news.uchicago.edu/story/lauren-berlant-preeminent-literary-scholar-and-cultural-theorist-1957-2021) from the original on June 29, 2021. Retrieved June 30, 2021.
10. **[^](#cite_ref-11)** Seitz, David (February 19, 2013). ["Lauren Berlant's queer optimism"](https://xtramagazine.com/power/lauren-berlants-queer-optimism-1224). _xtramagazine.com_. [Archived](https://web.archive.org/web/20210523161348/https://xtramagazine.com/power/lauren-berlants-queer-optimism-1224) from the original on May 23, 2021. Retrieved June 30, 2021.
11. **[^](#cite_ref-12)** Romero, Lora (1993). ["Making History"](https://www.jstor.org/stable/1345688). _Novel: A Forum on Fiction_. **26** (2): 215–222. [doi](/wiki/Doi_(identifier) "Doi (identifier)"):[10.2307/1345688](https://doi.org/10.2307%2F1345688). [ISSN](/wiki/ISSN_(identifier) "ISSN (identifier)") [0029-5132](https://www.worldcat.org/issn/0029-5132). [JSTOR](/wiki/JSTOR_(identifier) "JSTOR (identifier)") [1345688](https://www.jstor.org/stable/1345688).
12. **[^](#cite_ref-13)** ["American Literature Section: The Foerster Prize"](http://als-mla.org/FoersterList.htm). _Modern Language Association_. [Archived](https://web.archive.org/web/20210629214510/http://als-mla.org/FoersterList.htm) from the original on June 29, 2021. Retrieved June 29, 2021.
13. ^ [_**a**_](#cite_ref-:3_14-0) [_**b**_](#cite_ref-:3_14-1) Muñoz, José (2000). ["Citizens and Superheroes"](https://www.jstor.org/stable/30041852). _American Quarterly_. **52** (2): 397–404. [doi](/wiki/Doi_(identifier) "Doi (identifier)"):[10.1353/aq.2000.0021](https://doi.org/10.1353%2Faq.2000.0021). [ISSN](/wiki/ISSN_(identifier) "ISSN (identifier)") [0003-0678](https://www.worldcat.org/issn/0003-0678). [JSTOR](/wiki/JSTOR_(identifier) "JSTOR (identifier)") [30041852](https://www.jstor.org/stable/30041852). [S2CID](/wiki/S2CID_(identifier) "S2CID (identifier)") [145792484](https://api.semanticscholar.org/CorpusID:145792484). [Archived](https://web.archive.org/web/20210701013937/https://www.jstor.org/stable/30041852) from the original on July 1, 2021. Retrieved June 29, 2021.
14. ^ [_**a**_](#cite_ref-:4_15-0) [_**b**_](#cite_ref-:4_15-1) [_**c**_](#cite_ref-:4_15-2) Hesford, Victoria (2012). ["Review of The Female Complaint: The Unfinished Business of Sentimentality in American Culture"](https://www.jstor.org/stable/41475084). _Journal of the History of Sexuality_. **21** (2): 325–328. [doi](/wiki/Doi_(identifier) "Doi (identifier)"):[10.1353/sex.2012.0038](https://doi.org/10.1353%2Fsex.2012.0038). [ISSN](/wiki/ISSN_(identifier) "ISSN (identifier)") [1043-4070](https://www.worldcat.org/issn/1043-4070). [JSTOR](/wiki/JSTOR_(identifier) "JSTOR (identifier)") [41475084](https://www.jstor.org/stable/41475084). [S2CID](/wiki/S2CID_(identifier) "S2CID (identifier)") [142678449](https://api.semanticscholar.org/CorpusID:142678449). [Archived](https://web.archive.org/web/20210701013937/https://www.jstor.org/stable/41475084) from the original on July 1, 2021. Retrieved June 30, 2021.
15. **[^](#cite_ref-16)** ["Sentimental education"](http://magazine.uchicago.edu/0878/investigations/sentimental_ed.shtml). _The University of Chicago Magazine_. July–August 2008. [Archived](https://web.archive.org/web/20170722022154/http://magazine.uchicago.edu/0878/investigations/sentimental_ed.shtml) from the original on July 22, 2017. Retrieved June 30, 2021.
16. **[^](#cite_ref-17)** Berlant, Lauren. ["University of Chicago Department of English Language and Literature - Faculty"](http://english.uchicago.edu/faculty/berlant). [Archived](https://web.archive.org/web/20190601100340/http://english.uchicago.edu/faculty/berlant) from the original on June 1, 2019. Retrieved February 1, 2014.
17. ^ [_**a**_](#cite_ref-acReview_18-0) [_**b**_](#cite_ref-acReview_18-1) Yorker, A. Nerdy New (July 10, 2012). ["Academics Speak: Theory Review: Berlant's Cruel Optimism (2011)"](http://academicspeak.blogspot.com/2012/07/theory-review-lauren-berlants-cruel.html). [Archived](https://web.archive.org/web/20140228044157/http://academicspeak.blogspot.com/2012/07/theory-review-lauren-berlants-cruel.html) from the original on February 28, 2014. Retrieved August 7, 2013.
18. **[^](#cite_ref-19)** Berlant, Lauren. ["Interview With Lauren Berlant"](https://web.archive.org/web/20140202210157/http://societyandspace.com/material/interviews/interview-with-lauren-berlant/). Environment and Planning D: Society and Space. Archived from [the original](http://societyandspace.com/material/interviews/interview-with-lauren-berlant/) on February 2, 2014. Retrieved February 1, 2014.
19. **[^](#cite_ref-20)** Berlant, Lauren (2008). ["Thinking about feeling historical"](http://lucian.uchicago.edu/blogs/politicalfeeling/files/2009/01/berlant-thinking-about-feeling.pdf) (PDF). _Emotion, Space and Society_. Elsevier. pp. 4–9. [Archived](https://web.archive.org/web/20170227150103/https://lucian.uchicago.edu/blogs/politicalfeeling/files/2009/01/berlant-thinking-about-feeling.pdf) (PDF) from the original on February 27, 2017. Retrieved February 1, 2014.
20. **[^](#cite_ref-21)** Warner, Michael; Berlant, Lauren (May 1995). ["What Does Queer Theory Teach Us About X?"](https://www.cambridge.org/core/journals/pmla/article/abs/guest-column-what-does-queer-theory-teach-us-about-x/7A12630488328D9E4AEF03BC55C7D2E6). _PMLA_. **110** (3): 343–49.
21. **[^](#cite_ref-22)** Berlant, Lauren; Warner, Michael (January 1, 1998). ["Sex in Public"](https://www.journals.uchicago.edu/doi/abs/10.1086/448884). _Critical Inquiry_. **24** (2): 547–566. [doi](/wiki/Doi_(identifier) "Doi (identifier)"):[10.1086/448884](https://doi.org/10.1086%2F448884). [ISSN](/wiki/ISSN_(identifier) "ISSN (identifier)") [0093-1896](https://www.worldcat.org/issn/0093-1896). [S2CID](/wiki/S2CID_(identifier) "S2CID (identifier)") [161701244](https://api.semanticscholar.org/CorpusID:161701244). [Archived](https://web.archive.org/web/20210627214643/https://www.journals.uchicago.edu/doi/abs/10.1086/448884) from the original on June 27, 2021. Retrieved July 1, 2021.
22. **[^](#cite_ref-23)** Ayoub, Nina C. (June 22, 2001). ["Our Monica, Ourselves: The Clinton Affair and the National Interest"](https://www.chronicle.com/article/our-monica-ourselves-the-clinton-affair-and-the-national-interest/). _The Chronicle of Higher Education_. [Archived](https://web.archive.org/web/20210701013951/https://www.chronicle.com/article/our-monica-ourselves-the-clinton-affair-and-the-national-interest/) from the original on July 1, 2021. Retrieved July 1, 2021.
23. **[^](#cite_ref-24)** Worley, Sam (September 25, 2012). ["Laura Letinsky withdraws to a further remove"](https://www.chicagoreader.com/chicago/ill-form-and-void-full-valerie-carberry/Content?oid=7514183). _Chicago Reader_. [Archived](https://web.archive.org/web/20201029023556/https://www.chicagoreader.com/chicago/ill-form-and-void-full-valerie-carberry/Content?oid=7514183) from the original on October 29, 2020. Retrieved July 1, 2021.
24. **[^](#cite_ref-25)** Kipling, Ella (June 28, 2021). ["Twitter mourns Lauren Berlant's death: The "Cruel Optimism" author's legacy explained"](https://www.hitc.com/en-gb/2021/06/28/lauren-berlant-death/). _HITC_. [Archived](https://web.archive.org/web/20210628170855/https://www.hitc.com/en-gb/2021/06/28/lauren-berlant-death/) from the original on June 28, 2021. Retrieved June 28, 2021.
25. **[^](#cite_ref-26)** ["Collection: Lauren Berlant papers"](https://brown.as.atlas-sys.com/repositories/2/resources/405). Brown University Library Special Collections. [Archived](https://web.archive.org/web/20210701013937/https://brown.as.atlas-sys.com/repositories/2/resources/405) from the original on July 1, 2021. Retrieved June 29, 2021.

## External links[[edit](/w/index.php?title=Lauren_Berlant&action=edit&section=11 "Edit section: External links")]

- [University of Chicago faculty page](http://english.uchicago.edu/faculty/berlant) [Archived](https://web.archive.org/web/20190601100340/http://english.uchicago.edu/faculty/berlant) June 1, 2019, at the [Wayback Machine](/wiki/Wayback_Machine "Wayback Machine")
- [Lauren Berlant Papers](https://library.brown.edu/collatoz/info.php?id=509/)—Pembroke Center Archives, Brown University

|[Authority control databases](/wiki/Help:Authority_control "Help:Authority control") [![Edit this at Wikidata](//upload.wikimedia.org/wikipedia/en/thumb/8/8a/OOjs_UI_icon_edit-ltr-progressive.svg/10px-OOjs_UI_icon_edit-ltr-progressive.svg.png)](https://www.wikidata.org/wiki/Q12237573#identifiers "Edit this at Wikidata")|   |
|---|---|
|International|- [ISNI](https://isni.org/isni/0000000110836854)<br>- [VIAF](https://viaf.org/viaf/3978085)|
|National|- [Norway](https://authority.bibsys.no/authority/rest/authorities/html/5097052)<br>- [France](https://catalogue.bnf.fr/ark:/12148/cb129414841)<br>- [BnF data](https://data.bnf.fr/ark:/12148/cb129414841)<br>- [Germany](https://d-nb.info/gnd/136288928)<br>- [Italy](https://opac.sbn.it/nome/PUVV346055)<br>- [Israel](http://uli.nli.org.il/F/?func=find-b&local_base=NLX10&find_code=UID&request=987007462619505171)<br>- [Belgium](https://opac.kbr.be/LIBRARY/doc/AUTHORITY/14668312)<br>- [United States](https://id.loc.gov/authorities/n87104806)<br>- [Sweden](https://libris.kb.se/ljx150p4280z804)<br>- [Czech Republic](https://aleph.nkp.cz/F/?func=find-c&local_base=aut&ccl_term=ica=mub2014820283&CON_LNG=ENG)<br>- [Korea](https://lod.nl.go.kr/resource/KAC201601319)<br>- [Netherlands](http://data.bibliotheken.nl/id/thes/p191271810)<br>- [Poland](https://dbn.bn.org.pl/descriptor-details/9810546729505606)|
|Academics|- [CiNii](https://ci.nii.ac.jp/author/DA05722498?l=en)|
|Other|- [IdRef](https://www.idref.fr/074390872)|

![](https://login.wikimedia.org/wiki/Special:CentralAutoLogin/start?type=1x1)

Retrieved from "[https://en.wikipedia.org/w/index.php?title=Lauren_Berlant&oldid=1187106896](https://en.wikipedia.org/w/index.php?title=Lauren_Berlant&oldid=1187106896)"

[Categories](/wiki/Help:Category "Help:Category"):

- [1957 births](/wiki/Category:1957_births "Category:1957 births")
- [2021 deaths](/wiki/Category:2021_deaths "Category:2021 deaths")
- [American academics of English literature](/wiki/Category:American_academics_of_English_literature "Category:American academics of English literature")
- [Cornell University alumni](/wiki/Category:Cornell_University_alumni "Category:Cornell University alumni")
- [Gender studies academics](/wiki/Category:Gender_studies_academics "Category:Gender studies academics")
- [Jewish American writers](/wiki/Category:Jewish_American_writers "Category:Jewish American writers")
- [Jewish philosophers](/wiki/Category:Jewish_philosophers "Category:Jewish philosophers")
- [Oberlin College alumni](/wiki/Category:Oberlin_College_alumni "Category:Oberlin College alumni")
- [Queer theorists](/wiki/Category:Queer_theorists "Category:Queer theorists")
- [University of Chicago faculty](/wiki/Category:University_of_Chicago_faculty "Category:University of Chicago faculty")

Hidden categories:

- [Articles with short description](/wiki/Category:Articles_with_short_description "Category:Articles with short description")
- [Short description is different from Wikidata](/wiki/Category:Short_description_is_different_from_Wikidata "Category:Short description is different from Wikidata")
- [Use mdy dates from July 2021](/wiki/Category:Use_mdy_dates_from_July_2021 "Category:Use mdy dates from July 2021")
- [Articles with hCards](/wiki/Category:Articles_with_hCards "Category:Articles with hCards")
- [Webarchive template wayback links](/wiki/Category:Webarchive_template_wayback_links "Category:Webarchive template wayback links")
- [Articles with ISNI identifiers](/wiki/Category:Articles_with_ISNI_identifiers "Category:Articles with ISNI identifiers")
- [Articles with VIAF identifiers](/wiki/Category:Articles_with_VIAF_identifiers "Category:Articles with VIAF identifiers")
- [Articles with BIBSYS identifiers](/wiki/Category:Articles_with_BIBSYS_identifiers "Category:Articles with BIBSYS identifiers")
- [Articles with BNF identifiers](/wiki/Category:Articles_with_BNF_identifiers "Category:Articles with BNF identifiers")
- [Articles with BNFdata identifiers](/wiki/Category:Articles_with_BNFdata_identifiers "Category:Articles with BNFdata identifiers")
- [Articles with GND identifiers](/wiki/Category:Articles_with_GND_identifiers "Category:Articles with GND identifiers")
- [Articles with ICCU identifiers](/wiki/Category:Articles_with_ICCU_identifiers "Category:Articles with ICCU identifiers")
- [Articles with J9U identifiers](/wiki/Category:Articles_with_J9U_identifiers "Category:Articles with J9U identifiers")
- [Articles with KBR identifiers](/wiki/Category:Articles_with_KBR_identifiers "Category:Articles with KBR identifiers")
- [Articles with LCCN identifiers](/wiki/Category:Articles_with_LCCN_identifiers "Category:Articles with LCCN identifiers")
- [Articles with Libris identifiers](/wiki/Category:Articles_with_Libris_identifiers "Category:Articles with Libris identifiers")
- [Articles with NKC identifiers](/wiki/Category:Articles_with_NKC_identifiers "Category:Articles with NKC identifiers")
- [Articles with NLK identifiers](/wiki/Category:Articles_with_NLK_identifiers "Category:Articles with NLK identifiers")
- [Articles with NTA identifiers](/wiki/Category:Articles_with_NTA_identifiers "Category:Articles with NTA identifiers")
- [Articles with PLWABN identifiers](/wiki/Category:Articles_with_PLWABN_identifiers "Category:Articles with PLWABN identifiers")
- [Articles with CINII identifiers](/wiki/Category:Articles_with_CINII_identifiers "Category:Articles with CINII identifiers")
- [Articles with SUDOC identifiers](/wiki/Category:Articles_with_SUDOC_identifiers "Category:Articles with SUDOC identifiers")

- This page was last edited on 27 November 2023, at 14:34 (UTC).
- Text is available under the [Creative Commons Attribution-ShareAlike License 4.0](//en.wikipedia.org/wiki/Wikipedia:Text_of_the_Creative_Commons_Attribution-ShareAlike_4.0_International_License)[](//en.wikipedia.org/wiki/Wikipedia:Text_of_the_Creative_Commons_Attribution-ShareAlike_4.0_International_License); additional terms may apply. By using this site, you agree to the [Terms of Use](//foundation.wikimedia.org/wiki/Terms_of_Use) and [Privacy Policy](//foundation.wikimedia.org/wiki/Privacy_policy). Wikipedia® is a registered trademark of the [Wikimedia Foundation, Inc.](//www.wikimediafoundation.org/), a non-profit organization.

- [Privacy policy](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)
- [About Wikipedia](/wiki/Wikipedia:About)
- [Disclaimers](/wiki/Wikipedia:General_disclaimer)
- [Contact Wikipedia](//en.wikipedia.org/wiki/Wikipedia:Contact_us)
- [Code of Conduct](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal_Code_of_Conduct)
- [Developers](https://developer.wikimedia.org)
- [Statistics](https://stats.wikimedia.org/#/en.wikipedia.org)
- [Cookie statement](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
- [Mobile view](//en.m.wikipedia.org/w/index.php?title=Lauren_Berlant&mobileaction=toggle_view_mobile)

- [![Wikimedia Foundation](/static/images/footer/wikimedia-button.png)](https://wikimediafoundation.org/)
- [![Powered by MediaWiki](/static/images/footer/poweredby_mediawiki_88x31.png)](https://www.mediawiki.org/)

- Toggle limited content width