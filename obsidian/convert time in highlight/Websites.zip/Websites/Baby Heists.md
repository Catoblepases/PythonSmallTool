---
doc_type: hypothesis-highlights
url: 'https://thenewinquiry.com/baby-heists/'
---

# Baby Heists

## Metadata
- Author: [thenewinquiry.com]()
- Title: Baby Heists
- Reference: https://thenewinquiry.com/baby-heists/
- Category: #article

## Page Notes
## Highlights
- For the last half century, the international adoption of orphans has been used to cast imperial warfare and extraction as humanitarianism — [Updated on 2022-09-01 01:30:13](https://hyp.is/3KCNgCmEEe23Z4eS63RztA/thenewinquiry.com/baby-heists/) — Group: #Public




