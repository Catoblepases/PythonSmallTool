---
doc_type: hypothesis-highlights
url: 'https://mastodon.social/@tzenggustav?min_id=108749249111026110'
aliases: [乡间骑士 (@tzenggustav@mastodon.social)]
linter-yaml-title-alias: 乡间骑士 (@tzenggustav@mastodon.social)
date created: 2022-09-05
date modified: 2023-08-11
---

# 乡间骑士 (@tzenggustav@mastodon.social)

## Metadata
- Author: [mastodon.social]()
- Title: 乡间骑士 (@tzenggustav@mastodon.social)
- Reference: https://mastodon.social/@tzenggustav?min_id=108749249111026110
- Category: #article

## Page Notes
## Highlights
- 《在动物园散步才是正经事》即便和小机场后来的专辑相比 也是灵气逼人的那种 真的太喜欢了 — [Updated on 2022-09-05 16:12:26](https://hyp.is/xSK-qi0kEe2f_PcDPWR3bA/mastodon.social/@tzenggustav?min_id=108749249111026110) — Group: #inbox
- 《亚细亚的孤儿》这首歌之所以能够成为经典 在网易云的评论区里面 不少人说在昨晚佩洛西着陆的时候在听 然而谁是孤儿？『黄色的脸孔有红色的污泥 黑色的眼珠有白色的恐惧』『没有人和你玩平等的游戏 每个人都想要你心爱的玩具』『多少人在追寻那解不开的问题 多少人在深夜里无奈地叹息 多少人的眼泪在无言中抹去』 我看我们没有时间去仇恨别人 我们连可怜自己的自由都没有 — [Updated on 2022-09-05 16:13:43](https://hyp.is/8usHSC0kEe2-3l9JN4r1HQ/mastodon.social/@tzenggustav?min_id=108749249111026110) — Group: #inbox
- 是这样的，不妨都坦诚点。既然大家都势利就不要侈谈奉献，既然大家都空虚就不要侈谈理想，既然大家都低俗就不要侈谈艺术，既然大家都傲慢就不要粉饰成天命昭彰，否则所有人都会困惑，所有人都会难堪，不知道该接受哪种现实。让我们相信这一种：广场上一声枪响，理想便轰然倒地！我们没有命脉，因为它在倒在广场上的血泊里，我们没有文化，因为审查官将它删减得七零八落，我们没有母语，因为掩过饰非的、深文周纳的新话强占了我们的语言。从此我们宴聚只谈挣钱，我们出行只为了操劳，我们睡眠只为了躲藏。让我们承认我们的坏血统，像通灵者兰波那样。做一个名副其实的小人总比强装高尚轻松。这就是我感受到的人之生存的重压。 — [Updated on 2022-09-05 16:15:04](https://hyp.is/Iz4Hfi0lEe2cWVsWKWHbWQ/mastodon.social/@tzenggustav?min_id=108749249111026110) — Group: #inbox

