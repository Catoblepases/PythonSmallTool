---
doc_type: hypothesis-highlights
url: >-
  https://agorahub.github.io/pen0/heros/2014-10-21-Comit%C3%A9Invisible-a1_l-to-our-friends.html
---

# 致我们的朋友・ The Republic of Agora

## Metadata
- Author: [agorahub.github.io]()
- Title: 致我们的朋友・ The Republic of Agora
- Reference: https://agorahub.github.io/pen0/heros/2014-10-21-Comit%C3%A9Invisible-a1_l-to-our-friends.html
- Category: #article

## Page Notes
## Highlights
- 起义已经来临，但却不是革命。各地的革命似乎在暴乱阶段便已经熄灭，不是因为没有目标，而是因为我们与作为过程的革命已经脱节。而所有的起义，无论有多么在地，其意义必定远超自身：里面蕴含世界性的东西。因此，我们需要国际间的讨论，要从世界性高度的视角阐明起义和革命的意涵。 — [Updated on 2022-09-02 01:51:28](https://hyp.is/_0fkxCpQEe2GLvd6KihOUw/agorahub.github.io/pen0/heros/2014-10-21-Comit%C3%A9Invisible-a1_l-to-our-friends.html) — Group: #inbox




