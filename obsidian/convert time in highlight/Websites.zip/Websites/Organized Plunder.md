---
doc_type: hypothesis-highlights
url: 'https://thenewinquiry.com/organized-plunder/'
---

# Organized Plunder

## Metadata
- Author: [thenewinquiry.com]()
- Title: Organized Plunder
- Reference: https://thenewinquiry.com/organized-plunder/
- Category: #article

## Page Notes
## Highlights
- In the absence of the tax dollars city governments rely on, American are now funding themselves by fining the poor instead of taxing the rich — [Updated on 2022-09-07 17:47:43](https://hyp.is/aahsXi7EEe2z9P8y7QFcsw/thenewinquiry.com/organized-plunder/) — Group: #inbox




