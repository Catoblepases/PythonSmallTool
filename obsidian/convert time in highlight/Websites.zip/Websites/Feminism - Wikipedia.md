---
doc_type: hypothesis-highlights
url: 'https://en.wikipedia.org/wiki/Feminism'
---

# Feminism - Wikipedia

## Metadata
- Author: [en.wikipedia.org]()
- Title: Feminism - Wikipedia
- Reference: https://en.wikipedia.org/wiki/Feminism
- Category: #article

## Page Notes
## Highlights
- Feminism is a range of socio-political movements and ideologies that aim to define and establish the political, economic, personal, and social equality of the sexes. — [Updated on 2022-08-30 23:08:29](https://hyp.is/5ZY8TCinEe27XhczlNAmgA/en.wikipedia.org/wiki/Feminism) — Group: #Public

- Some scholars consider feminist campaigns to be a main force behind major historical societal changes for women's rights, particularly in the West — [Updated on 2022-08-30 23:09:21](https://hyp.is/BMzqICioEe2089uytQsI-A/en.wikipedia.org/wiki/Feminism) — Group: #Public

- Feminist theory, which emerged from feminist movements, aims to understand the nature of gender inequality by examining women's social roles and lived experience; feminist theorists have developed theories in a variety of disciplines in order to respond to issues concerning gender. — [Updated on 2022-08-30 23:10:01](https://hyp.is/HJ63jCioEe23Kxtz8iwvqw/en.wikipedia.org/wiki/Feminism) — Group: #Public





