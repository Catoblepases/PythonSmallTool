---
doc_type: hypothesis-highlights
url: >-
  https://agorahub.github.io/pen0/heros/2023-10-19-Anonymous-a1_l-the-machiavellian-dilemma-of-left-wing-politics.html
---

# 左翼政治的马氏难题 · The Republic of Agora

## Metadata
- Author: [agorahub.github.io]()
- Title: 左翼政治的马氏难题 · The Republic of Agora
- Reference: https://agorahub.github.io/pen0/heros/2023-10-19-Anonymous-a1_l-the-machiavellian-dilemma-of-left-wing-politics.html

## Page Notes
## Highlights
- 文末，笔者将探讨究竟是苏联化的马克思主义失败了还是马克思主义本身失败了的问题。 — [Updated on 2023-12-07](https://hyp.is/4bzmZpUCEe6Pt5-njeKptA/agorahub.github.io/pen0/heros/2023-10-19-Anonymous-a1_l-the-machiavellian-dilemma-of-left-wing-politics.html) — Group: #inbox




