---
doc_type: hypothesis-highlights
url: 'http://looandlougallery.com/exhibitions/'
---

# Tanc: Fragments | Exhibitions | MutualArt

## Metadata
- Author: [looandlougallery.com]()
- Title: Tanc: Fragments | Exhibitions | MutualArt
- Reference: http://looandlougallery.com/exhibitions/

## Page Notes
## Highlights
- With his Fragments series, Tanc operates a new variation within his own work. This time, the artist inventor of abstract writings reveals surprising diffracted calligraphies. He changes his practice, and passes from a continuous flow to a discontinuous flow. Thus the uninterrupted gesture which consisted in covering a surface becomes the occasion of a fragmentation of the surface itself. To the beautiful totality of a canvas composed like a page, from left to right, from top to bottom, the artist prefers the way of the fragment. Diffracting the One, he carries out a new internal cutting of the painting. Change its syntax by changing its rhythm. The Fragments series rethinks the relationship between the different styles previously developed by the artist, as it functions as a new mise en abyme of the work within the work. For, as Tanc himself says, his goal is to "rewrite his language constantly. — [Updated on 2023-02-25](https://hyp.is/AJC9hrUiEe2Lt5dDgZ3wjQ/looandlougallery.com/exhibitions/) — Group: #inbox




