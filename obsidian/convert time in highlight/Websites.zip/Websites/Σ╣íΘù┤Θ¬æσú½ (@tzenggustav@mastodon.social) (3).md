---
doc_type: hypothesis-highlights
url: 'https://mastodon.social/@tzenggustav?min_id=108756774279018566'
---

# 乡间骑士 (@tzenggustav@mastodon.social)

## Metadata
- Author: [mastodon.social]()
- Title: 乡间骑士 (@tzenggustav@mastodon.social)
- Reference: https://mastodon.social/@tzenggustav?min_id=108756774279018566
- Category: #article

## Page Notes
## Highlights
- 我想要的是一种观念的电影 le film d'idée 它不是靠譬喻完成的，也不是靠剪辑完成的，更不是靠画面完成的。我只想融合中国的美学经验和全人类的历史历险，经由观念性和存在性的螺旋上升，成就一种诗和真理合一的电影。 — [Updated on 2022-09-05 16:16:00](https://hyp.is/RKcLwi0lEe2QAONVWw0uAg/mastodon.social/@tzenggustav?min_id=108756774279018566) — Group: #inbox




