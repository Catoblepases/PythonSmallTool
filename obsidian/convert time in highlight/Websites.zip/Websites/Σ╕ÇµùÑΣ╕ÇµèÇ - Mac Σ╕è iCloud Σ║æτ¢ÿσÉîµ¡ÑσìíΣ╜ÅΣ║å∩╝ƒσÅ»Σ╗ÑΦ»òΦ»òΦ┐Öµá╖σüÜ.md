---
doc_type: website
url: 
date created: 2023-10-28
date modified: 2023-10-28
---
依靠云盘同步而不是 U 盘，确实极大地方便了我们的移动办公体验。而 Apple 设备自带的 iCloud 云盘则是文件同步的利器，除了可以像日常的个人网盘一样使用之外，还集成了 Mac 设备的桌面与文稿，不可谓是不方便。然而，iCloud 同步文件有的时候确实有些「玄学」，除了突然卡住、文件不能同步之外，iCloud 云盘有时还会让整台 Mac 电脑变慢甚至是风扇转速「起飞」。

Apple 官方的支持论坛上相关的 [帖子](https://discussionschinese.apple.com/thread/251358126) 获得了 190 个「我也有类似问题」的反馈，说明问题绝对不是只发生在一两个人身上。文本将简单介绍 iCloud 云盘同步卡住的表现、原因，列出可能的解决方案，希望可以帮到大家。

![](https://cdn.sspai.com/editor/u_/c9j157tb34tee6vbamr0.png)

图片来自互联网

正如上文所述 Mac 上 iCloud 云盘同步卡住时，最容易注意到的现象就是在访达的 iCloud 云盘旁边显示一个永远也不会被填满的圆圈，而且点击这个圆圈，还有一个永远走不满的进度条，甚至 macOS 还会直接弹窗提示「你某某文件无法进行同步」。

![](https://cdn.sspai.com/editor/u_/c9j1585b34ted3sbp1a0.png)

图片来自互联网

反映在实际使用中，你在一个设备上创建的文件均无法通过 iCloud 云盘，下载到 Mac 或是另一台设备上，在 Mac 上创建的文件则完全无法同步到云端。

iCloud 云盘卡住不同步已经很糟糕了，更糟糕的是 iCloud 云盘同步卡住可能会进一步降低 macOS 的性能。这一点会具体体现在你可以在活动监视器中查看到大量的 icloudd 或者 bird 进程<sup href="" footnote-id="1" data-title="macOS 中有关 iCloud 文件同步的核心进程">1</sup>

，而且这些进程都在大量使用 CPU，让你的 mac 不仅没资源处理其他的事情而且变得又热又吵。

此外，还有一种更加靠谱的方式来检查你 iCloud 云盘同步是否出现了问题，即在终端里输入：`brctl log -w`检查日志输出。

![](https://cdn.sspai.com/editor/u_/c9j158db34ted3sbp1ag.png)

这个命令能够将 iCloud 同步过程中各种信息直接显示到屏幕上，方便我们进行诊断，虽然吐出来的日志记录非常「事无巨细」，但我们只需要关注有无类似下图的错误信息或者有不断滚动的检索队列，就能确认我的 iCloud 云盘同步已经卡住了。

![](https://cdn.sspai.com/editor/u_/c9j158lb34tee6vbamrg.png)

如果你不太适应终端，那么可以使用 [Circus](https://sspai.com/link?target=https%3A%2F%2Feclecticlightdotcom.files.wordpress.com%2F2021%2F04%2Fcirrus112.zip) 这款小工具，来可视化 iCloud 中文件的同步进程。这款工具可以帮助你查看上文中提到的 log、查看当前 iCloud 文件的状态、下载当前 iCloud 云盘中存储的文件，或者是将存储在本地的 iCloud 文件清除。详细的使用方式，可以查看随附在 Circus 安装包中的文档，十分详尽，甚至列出了它的原理。

![](https://cdn.sspai.com/editor/u_/c9j158lb34tee6vbams0.png)

![](https://cdn.sspai.com/editor/u_/c9j158tb34teed0ilqtg.png)

## 😶🌫️ 有哪些原因会导致 iCloud 云盘同步卡住

由于 iCloud 云盘本身实现的机制非常复杂，所以卡住的原因也各有不同，从网络上不少与之相关的论坛的帖子中，可以简单总结出几个可能导致 iCloud 云盘同步卡住的原因：

-   网络问题
-   一次性向 iCloud 云盘塞入了过多需要同步的文件
-   文件夹嵌套层级太多
-   Apple ID 转区

首先，iCloud 云盘同步非常依赖网络，如果你的**互联网络质量很差**或者**无线网络连接质量很差**，iCloud 云盘同步会有大概率会卡住。如果你确定自己的网络应该没有问题，那么可以到 Apple 官方的 [系统状态](https://www.apple.com.cn/cn/support/systemstatus/) 页面，查看 iCloud 服务的目前状态。

![](https://cdn.sspai.com/editor/u_/c9j1595b34teed0ilqu0.png)

通过 Apple 官方的 [系统状态](https://www.apple.com.cn/cn/support/systemstatus/) 页面，可以查看 iCloud 服务的目前状态

例如，目前中国大陆地区 iTunes Store 和 Apple Books 处于服务中断状态，可以看到**红色的三角形**。如果是 iCloud 出现服务状态问题，那么届时与 iCloud 相关的服务项也会在一旁出现红色的三角形。点击具体的服务项，还可以看到目前服务中断开始的时间、结束的时间，以及影响范围。

其次，如果你**一次性向 iCloud 云盘塞入了过多需要同步的文件**，iCloud 云盘进程在同步前就需要进行大量的计算和检索，花费时间会变长、占用资源变多，如果这时其中有一个文件又问题，很有可能会卡住整个 iCloud 云盘同步的进度。如果桌面或者文稿文件夹中有大量文件的 Mac ，突然打开了对应 iCloud 云盘的「桌面与文稿」同步功能，就非常有可能会出现这样前面提到的情况。

![](https://cdn.sspai.com/editor/u_/c9j159db34tee6vbamsg.png)

iCloud 开始拒绝同步具有大量文件或者嵌套大量文件夹的文件夹，[图源](https://sspai.com/link?target=https%3A%2F%2Fwww.v2ex.com%2Ft%2F841605)

此外，**文件夹嵌套层级太多**也可能是另一个原因，和**一次性向 iCloud 云盘塞入了过多需要同步的文件**的道理相似，过多的文件夹嵌套层级也可能会增加 iCloud 云盘在同步时的计算量与出错风险。而在最新的 [信息](https://sspai.com/link?target=https%3A%2F%2Fwww.v2ex.com%2Ft%2F841605) 中显示，iCloud 云盘似乎已经拒绝同步带有太多嵌套层级的文件夹。

最后，**Apple ID 转区**导致的 iCloud 云盘卡住，是编辑 Lincoln 朋友遇到的一个情况。我们只能简单猜测在转区的过程中，需要对大量文件进行迁移操作，如果这时同步新的文件上去可能导致冲突，进而导致同步问题。

## 👇 可以试着这样解决

iCloud 云盘同步出现出了问题自然是需要解决的，一来是我们还需要用 iCloud 云盘同步数据，二来则是如果不管的话，[可能](https://sspai.com/link?target=https%3A%2F%2Fwww.v2ex.com%2Ft%2F841605) 会导致更严重的后果，诸如：本地 Finder 操作缓慢甚至彻底卡死、内置硬盘被 iCloud 云盘相关进程的读写任务占据大量资源、Time Machine 无法备份甚至是无法开机。

考虑到每个人 iCloud 卡死的原因各不相同，解决方案侧重点也不太一样，此外每一个的技术背景也各有不同。因此在写这个部分的时候，我们的考虑是：「尽量减少操作对系统和数据的影响」。所以下面的解决方案是以危险性从低到高排列的，很可能前面的 1-2 条方案就已经解决了你的问题。

第一个可能解决的办法就是**什么也不做。**尽管听起来很不「少数派」，但是如果你是刚刚发现 iCloud 同步出现了一些问题，并且要同步的文件不是很着急使用的话，我们还是建议你什么都不做。因为绝大多时候，iCloud 云盘卡死都可能是网络出现了问题，或者这一部分文件需要花费更多的时间去索引。通常换个网络环境，或是过个一段时间，iCloud 云盘就能自行恢复到了正常同步的状态。如果在卡死的时间段内需要同步文件，那么可能就需要寻找一些其他的解决方案了，比如基于本地局域网的 [隔空投送](https://support.apple.com/zh-cn/HT204144)，或者是 [KDE Connect](https://sspai.com/post/68779) 等。

第二个可能解决的办法就是「重 x 大法」，包括**重置进程、重启网络、重开电脑、重新登录 Apple ID 以及重装系统**。这些办法虽然在互联网上已经老生常谈，但架不住能在 99% 的情况下解决问题。**重置进程**就是通过 `killall bird` 和 `killall cloudd` 两个命令，将 iCloud 云盘最紧密的两个进程 bird 和 cloudd 进程手动杀死。这两个进程被终止后，macOS 会自动重新将这两个进程拉起，这时我们就可以重新观察 iCloud 云盘的同步情况；**重启网络、重开电脑** 也很简单，这里不再赘述。如果需要**重新登录 Apple ID**，我的建议是从你的其他 Apple 设备上使用 iCloud 设备管理功能将这台同步有问题的 Mac 剔出 Apple ID 账户，待 bird 和 cloudd 进程恢复正常以后再重新登录。最后，如果上述办法都没能够解决你的问题，那么可以试着**在做好系统数据备份的情况下重装系统**，检查 iCloud 是否恢复正常。

![](https://cdn.sspai.com/editor/u_/c9j159lb34ted3sbp1b0.png)

从 iCloud 中主动踢出设备可能更有助于解决「玄学」问题

第三个办法就是 **引导系统重新建立 CloudDocs 文件夹**，这个解决方案来自 [StackExchange](https://sspai.com/link?target=https%3A%2F%2Fapple.stackexchange.com%2Fquestions%2F313716%2Ficloud-drive-wont-sync-on-mac)。CloudDocs 文件夹位于用户个人资源库的应用程序支持模块中，是 iCloud 文件同步的支持文件。通过删除或者移动这些文件，我们可以引导系统重新建立一套新的文件用于 iCloud 文件同步，可能就可以解决卡住的问题。重建这个文件夹的方式，可以打开终端，输入以下命令：

```
killall bird    # 结束 bird 这一 iCloud 文件同步的核心进程
killall cloudd    # 结束 cloudd 这一 iCloud 文件同步的核心进程
cd ~/Library/Application\ Support    # 终端要处理的文件夹转换到用户资源库
mv CloudDocs CloudDocsOld   # 将原本 Application Support 文件夹中的 CloudDocs 文件夹重新命名成为 CloudDocsOld
```

敲完上面四行之后，我们也需要等待几个小时，观察文件是否可以开始正常同步。

最后但应该是最有效的办法**：联系 Apple 支持，请求重置 iCloud 云盘账户。**如果上面的方法都不能解决你的 iCloud 同步问题，并且出现了上文提到的更严重的后果，那么就要考虑是不是需要整个清空 iCloud 云盘账户了。普通（甚至是高级）的接线员确实没有办法重置你的 iCloud 云盘账户，但是工程部可以。找一个空闲时间较多的一个周末，通过 Apple 官网发起 [iCloud 支持](https://getsupport.apple.com/topics) 请求，和接线员做完基础的排查工作以后（大概率就是第二步），就可以请求「让工程部重置你的 iCloud 了」，更专业的说法应该是「让工程部重置你的 iCloud 容器」。这一定能使你的 iCloud 云盘账户恢复正常，但数据自然会被清空 —— 不是万不得已，还是不要动用这样的核弹级解决方式了。

## 🌚 写在最后

iCloud 的玄学有目共睹。运行平稳的时候，它是我高效工作的好帮手；但是一旦出了问题，似乎解决问题的时间成本确实有点儿高。在网络环境似乎还没有达到理想状态的今天，似乎最后只能是多点备份、多点耐心、少点戾气 —— 对待 iCloud 如此，其他云服务也是如此。

管理 iCloud 文件，也还可以使用 [Bailiff](https://sspai.com/link?target=https%3A%2F%2Feclecticlightdotcom.files.wordpress.com%2F2020%2F08%2Fbailiff15.zip) 这款小工具 —— 它可以帮助你在菜单栏控制某个文件是否应当保存在云端，或者是留在本地。

当然除去 iCloud 本身的问题，有些使用上的问题也值得注意，比方说各种云盘服务并不适合同步代码和 git 库。同步代码库时，不仅同步效率低下，同步常常会出现错、漏文件的情况，这时应该使用 git 工具来同步这些代码。

以上就是本文的全部内容，希望可以帮助到你。

\> 下载 [少数派 2.0 客户端](https://sspai.com/page/client)、关注 [少数派公众号](https://sspai.com/s/J71e)，解锁全新阅读体验 📰

\> 实用、好用的 [正版软件](https://sspai.com/mall)，少数派为你呈现 🚀
