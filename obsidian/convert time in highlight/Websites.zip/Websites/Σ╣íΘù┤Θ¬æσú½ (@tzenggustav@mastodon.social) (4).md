---
doc_type: hypothesis-highlights
url: 'https://mastodon.social/@tzenggustav?min_id=108804861260614450'
---

# 乡间骑士 (@tzenggustav@mastodon.social)

## Metadata
- Author: [mastodon.social]()
- Title: 乡间骑士 (@tzenggustav@mastodon.social)
- Reference: https://mastodon.social/@tzenggustav?min_id=108804861260614450
- Category: #article

## Page Notes
## Highlights
- 今晚和母亲那边的家族吃饭，晚上回到父亲这边来住，感觉风格相差极为明显。和母亲那边的亲族争论了半天比特币和区块链，虽然她们也只是把这个当成一个比较新潮的搞钱的手段（我们后面很顺理成章地开始说怎样利用拼多多的规则漏洞），但我也很震惊区块链能染上多少平民色彩，我觉得这是一种国情，就是说很难形成一种非常排他的非常封闭的阶层文化，每一种阶级意识和实践都在向其他的所有阶层，尤其是平民阶层渗透，所以在中国任何看起来脱离了百姓群众的行为很容易被集中火力，这本身就是这种国情的体现。回到我爹家里之后就觉得窒闷，是一潭死水的那种小市民家庭。 — [Updated on 2022-09-05 16:24:47](https://hyp.is/fmSccC0mEe2nNvMfenXqTw/mastodon.social/@tzenggustav?min_id=108804861260614450) — Group: #inbox




