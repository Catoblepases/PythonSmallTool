---
doc_type: hypothesis-highlights
url: >-
  https://blog.apaonline.org/2019/04/24/women-in-philosophy-the-limits-of-consent-in-sexual-ethics/
---

# Women in Philosophy: The Limits of Consent in Sexual Ethics

## Metadata
- Author: [blog.apaonline.org]()
- Title: Women in Philosophy: The Limits of Consent in Sexual Ethics
- Reference: https://blog.apaonline.org/2019/04/24/women-in-philosophy-the-limits-of-consent-in-sexual-ethics/

## Page Notes
## Highlights
- Consent reinforces the idea that men ask for sex and women respond — [Updated on 2023-12-07](https://hyp.is/XMzXbJT-Ee63YLOeZPae3w/blog.apaonline.org/2019/04/24/women-in-philosophy-the-limits-of-consent-in-sexual-ethics/) — Group: #inbox

- Consent fails to register the temporally unfolding nature of sexual encounters — [Updated on 2023-12-07](https://hyp.is/ZqjWoJT-Ee6H6ieOlaf6pQ/blog.apaonline.org/2019/04/24/women-in-philosophy-the-limits-of-consent-in-sexual-ethics/) — Group: #inbox

- Here, scholars argue that consent may not be the best—let alone the only—concept for distinguishing positive sexual encounters from harmful, assaultive ones. — [Updated on 2023-12-07](https://hyp.is/hNHrqJT-Ee69Qq-pDsLI-A/blog.apaonline.org/2019/04/24/women-in-philosophy-the-limits-of-consent-in-sexual-ethics/) — Group: #inbox

- Recently, the #Metoo movement has given feminist scholars all the more reason to question the notion of consent. — [Updated on 2023-12-07](https://hyp.is/kYWm-pT-Ee6PsMdxbB_OOA/blog.apaonline.org/2019/04/24/women-in-philosophy-the-limits-of-consent-in-sexual-ethics/) — Group: #inbox

- Rebecca Kukla has persuasively argued that sexual encounters are better rendered by the notions of ‘invitation’ and ‘gift’ than by that of consent. — [Updated on 2023-12-07](https://hyp.is/qRpYzpT-Ee6ny9crre1xvg/blog.apaonline.org/2019/04/24/women-in-philosophy-the-limits-of-consent-in-sexual-ethics/) — Group: #inbox




