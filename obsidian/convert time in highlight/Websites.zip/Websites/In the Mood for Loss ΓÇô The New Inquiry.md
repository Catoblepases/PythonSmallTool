---
doc_type: hypothesis-highlights
url: 'https://thenewinquiry.com/in-the-mood-for-loss/'
---

# In the Mood for Loss – The New Inquiry

## Metadata
- Author: [thenewinquiry.com]()
- Title: In the Mood for Loss – The New Inquiry
- Reference: https://thenewinquiry.com/in-the-mood-for-loss/
- Category: #article

## Page Notes
## Highlights
- Unfortunately, the idea that Hong Kong’s free markets were one part of some free society to be realized in the future was never anything more than a comforting fiction.  — [Updated on 2022-08-31 03:48:20](https://hyp.is/_gGPgCjOEe2ruPek3GXAZQ/thenewinquiry.com/in-the-mood-for-loss/) — Group: #inbox

- Over time, free markets became considered a sign of the city’s political health. For decades, Hong Kong topped global measures of economic freedom. When the Heritage Foundation finally removed Hong Kong from the Economic Freedom Index in 2021, it signaled the end of an era. A set of roundly mocked tweets proclaimed the death of the city. “RIP Hong Kong,” they read. “1842-2020.” — [Updated on 2022-09-02 00:28:02](https://hyp.is/V58W2ipFEe21Bw_GhHkW2Q/thenewinquiry.com/in-the-mood-for-loss/) — Group: #inbox




