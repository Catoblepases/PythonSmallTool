Sindy 作为悉尼大学教育学硕士，当年去留学几乎没有备考，依靠多年沉浸于托雅语培的教学经验，裸考就取得了托福 112 分的成绩，对于这个问题还是略有心得的。

接下来我会详细从备考时间安排和具体每个科目应该怎么备考跟大家做一个详细讲述。全文内容比较长，全是干货，大家可以收藏慢慢看。

让我们计算得更加精确一点：从现在开始努力三个月，也就是 90 天，假设每天有效学习 TOEFL 的时间是 4 个小时，那 90 天下来总共 360 个小时。按照这个进度，假设基础在 TOEFL80+，3 个月以后达到 100 + 希望还是灰常大的。Sindy 之前回答过一个类似的，不过那是从 CET 六级过线的水平开始的，一时写 High 了超过了知乎的上限，被系统告知写不下了，于是这版的回答做了一些删减。

接下来看学习方法：

学习方法可以分为 5 个模块：（1）单词 ，（2）听力，（3）阅读，（4）口语，（5）写作

咱们一一来看：

**（1）单词**

学习资料：一是《托福 IBT 词以类记》，二是上面说的百词斩、扇贝、拓词。

使用方法：单词书，一本足矣。词以类记这本书共有 9 章。（网上可以下到电子版的）

1\. 学术学科 书本的 P3-119

2\. 品质 书本的 P132-144

3\. 事物 书本的 P148-170

4\. 现实 书本的 P173-204

5\. 心理 书本的 P205-221

6\. 行为 书本的 P226-265

7\. 语言 书本的 P270-282

8\. 属性 书本的 P286-312

9\. 状态 书本的 P313-335

从页数上就可以看出来，第一章是一个巨无霸，从第 3 页一直到第 119 页，里面包含了从地质学，动物学，化学，农业，天文，音乐，经济，军事等等的各个学科词汇。这些不同领域的学术词汇对托福听力的 lecture、阅读文章、综合写作、和口语 Q4Q6 都很有帮助，但是由于覆盖面太广，专业词汇太多，所以，背起来会比较吐血。不建议一上来就这么自虐，最好先记忆一个科目就找到听力中相应的练习做一做缓一缓，（新地会在后面的听力部分写清楚哪些听力的段子是和神马学科一一对应的。）

而从第二章开始，每一个章节的长度瞬间就短了好多，而且生活中的实用性也提升了。如果第一章背吐了可以拿第二章的词汇漱漱口。

上面说的是重点解决学术词汇，那么听力的 conversation 部分和口语中的词汇怎么搞定捏？网上找找其实有一大堆，但是，重点绝对不是量，而是真的遇见能识别能理解的能力。另外，速度的话，上面咱们计算过，一天背一页的单词，第二天背新的一页的时候记得复习前一天的量，复习 3 天以后 move on。

**（2）听力，**

学习资料：OG, TPO1-30

使用方法：

OG, 也就是托福的官方指南，网上能下到电子版的。见图

![](https://picx.zhimg.com/50/ea065f26ecccce2dee4c33401b375e00_720w.jpg?source=1940ef5c)

先把听力的那个章节看完，考试形式和题型就都明白啦。

再去下载一个 “TPO1-36 模考软件 V4.2.1”

安装完成以后，按照下面截图的路径打开文件：

于是，你就拥有了 TPO1-36 的听力音频，顺带还有综合口语音频和综合写作音频。

![](https://pic1.zhimg.com/50/727e6a1e5c97f05aa037c32fb6da307c_720w.jpg?source=1940ef5c)

好了，我们现在来讲有了这些资料怎么自学：

首先，起点。直接来一次**裸考自测**还是有必要的，不是用来打击自己，而是用来给 360 小时以后的你一种赤果果的成就感。还有更重要的是，要搞清楚，自己有以下哪几种问题：

1.  真的啥都听不清，感觉自己和聋了一样
2.  听清了，就是没听懂，不知道什么意思，尤其是句子长的时候
3.  貌似听懂了每一句话，但是脑子转速跟不上
4.  听懂了不止句子，而是一大段，但是笔记不下来，脑记也记不全 。

接下来，启程。听力其实就是磨耳朵的过程没错，但是大部分的老师和学霸都只会说 “多听呀”，然后就闭上嘴了，那么他们都不是真的爱你。正确的打开方式是：如果你是上面的（1）（2）（3）问题，你需要练习的是一边背单词，一边学文本，一边听音频。这里不是说时间上完全同时发生，而是说，最好是一天之内，先背诵词以类记中一个学科的单词，比如说地质学，然后去找听力中地质学的段子来听，听不下来就看着文本不停按 pause 地学。哦，学科段子怎么找是吧？新地自己整理了一个文档，和大家分享，见下图：

![](https://picx.zhimg.com/50/d0c533f979ba1283c68baf94cc0ed3b7_720w.jpg?source=1940ef5c)

![](https://pic2.zhimg.com/50/139227ec77bb27073cdf849de648ff29_720w.jpg?source=1940ef5c)

![](https://pic2.zhimg.com/50/41c4425b40614e65e76f95f22d7492a4_720w.jpg?source=1940ef5c)

听力的文本和题目都可以在网上搜到。只要挑着自己薄弱的学科练 lecture 就好。

另外，如果是上述问题中（3）（4）现象的话，那在这个练习的基础上，还得加一个，把听力文本拿来做切割的练习，这个练习可不像水果忍者切西瓜那么随意那么任性，而是找到文中的起承转合来给 lecture 做划分。就像下图这样，一开始的时候，看着文本做切割，标明 lecturer 讲的哪一段话是废话，哪一点引出了话题的核心，哪一段讲了一个例子，哪部分又说了谁谁提出了什么异议，谁谁过来砸场子云云的。

![](https://pic2.zhimg.com/50/76d7c230c1ac35902b2cefc22a36c44d_720w.jpg?source=1940ef5c)

慢慢学会了这种切割 lecture 的方式，你就可以让耳朵有选择地去抓住 lecture 脉络。争取在不看文本光听的时候也能做到划分。在笔记中用 “/“ 这个符号来分割笔记就好。新地这里献丑一个自己的笔记上来给大家做个示范。

![](https://pic2.zhimg.com/50/c290c96fb2e92ed7f6ba5aab715cb0b3_720w.jpg?source=1940ef5c)

对，就这么练，然后捏，就是做题啦。除了看网上能下载到的听力解析之外，其实还有一个更有效的听力做题能力提升的方法，其实细心的话，大家能看到，上面这图里面，新地标出了题号，没错，这些标上题号的就是出题点。毫无例外地，这些出题点都在逻辑衔接的地方出现。如果楼主也这么做笔记标题号，三套 lecture 下来，感觉就出来了，预见出题点神马的绝对不是特异功能，你也可以哦。

另外，关于听力，成天抱着 TPO 也会有省美疲劳的，当然，还有很多从来就没觉得它美过那就更加不用说了。

休息的时候，除了看美剧，其实还有一个不错的方式是听 radio。咳咳，我知道大家会觉得新地比较老土，但是不得不推荐一个很棒的 app，叫做趴趴英语，作为一个走心的线上英语学习平台，趴趴英语在它的发现模块中的听力频道提供了大量真题听力及鸡精听力，可谓日常磨耳朵之必备良品。另外他最近更推出了托福 0 元课，解题小技巧挺 nice，还有解疑答惑，包含 4 节联播课程 + 资料分享 + 学习群互动指导。链接我就放在下面了，有需求的小伙伴不妨试听看看。  

————————————————————————————————————————————

回来啦，接着聊：

先对上一次回答做一下补充，如果手机上图看不清就上电脑端，新地自己试过，倍儿清楚。

（1）关于单词书的选择，其实如果考生们手头已经有了自己背得得心应手的词汇书，那就继续用，也不见得非要改用《词以类记》。毕竟单词书一本足矣，重点在于运用。开心就好。

（2）关于下片子。各位同学们都为了下图桑心抹泪，貌似昔日的美剧英剧都已经成为曾经。

![](https://pic4.zhimg.com/50/66f471d2e6e4af7647f8acd592ce6212_720w.jpg?source=1940ef5c)

不要怕，昨天远程经过一位少年郎的指点，新地才知道原来一切都还在，见图：注意**域名**

![](https://pica.zhimg.com/50/3321ae16b61bc56df3335b148fe5bf11_720w.jpg?source=1940ef5c)

在这里，大家都还在。真是普大喜奔呀。

好啦，我们接着讲干货

**（3）阅读，**

学习资料：OG, TPO1-30

使用方法：

还是先把 OG 的这一章看完。见图：

![](https://pic2.zhimg.com/50/7292df4bdd6e63ab9e38f4cdedaab5ad_720w.jpg?source=1940ef5c)

网上有些帖子说看 OG 没用，但是仔细想想，毕竟这是官方给出的唯一对考试的说明，里面满满透露了考官们的动机，和出题官虐人的手法。如果用自己独立的思维捋出要点，那定是比网上流言蜚语以讹传讹要好上 N 倍的。

言归正传，然后捏？

直接上 TPO，拿 3 个 reading passages 出来看看裸泳的自己是什么水平。这里要看出来的是自己存在的能力点上的 problem，而不是 superficial 的：时间不够，错一大堆，看不懂，好烦，想扔掉。。。。你应该挖掘的是自己有没有下面这几种障碍：

1.  单词不认识，数量在平均每个 passage 有 30 个以上的非专业名词的不认识
2.  单词都认识，句子看不懂，每个篇章有 5 个以上的长句子看不懂的
3.  句子几乎都看懂，但是句间关系理不清楚的，只能靠毛估的
4.  段落间关系只能靠毛估的
5.  词句没问题，但是整个文章看完觉得作者吃饱了撑着写得很凌乱

我们一个一个来看。

**克服障碍（1）：**单词不认识。数量在平均每个 passage 有 30 个以上的非专业名词的不认识。

这绝对是一个比较低段位的障碍，但是总归得过呀。首先，怎么统计自己非专业名词不认识的个数？先来看什么是专业名词，举个栗子，就像 timberline 这种，在 TPO1 的 reading passage 03 中出现，意思是 “树带界线”，绝对感觉中文都不像是我们能秒懂的词汇，当然，一般这种词汇，文章会给出解释，比如 “The transition from forest to treeless tundra on a mountain slope is often a dramatic one. Within a vertical distance of just a few tens of meters, trees disappear as a life-form and are replaced by low shrubs, herbs, and grasses. This rapid zone of transition is called the upper timberline or tree line.” 于是就感觉终于说人话了，“timberline” 就是山上从树多地带到短毛草地之间的过渡区域。

那么非专业名词，就是指除了这些专业名词的词，可以是动词，形容词，抽象名词，具象名词，总之是人话，就拿上面这句举些栗子：disappear，replace，dramatic，transition，shrub 等等。如果平均每个 passage 有 30 个以上的非专业名词的不认识，那么，**抓！紧！背！单！词！** 不光是抱着单词书背，还得把 passage 里面的生词挑出来先背了再去看文章。速度很慢，但是很有效，往往看五个 reading passage 下来就可以找出一些高频词出现的规律了。当然，听力的词汇 pool 和阅读的词汇很多是共同的，一石二鸟的感觉很爽吧。另外，提醒一句，别太把词汇书里或者字典里的单词的中文解释太当回事儿，有时候在地道的原版文章中得用法会让我伙呆得很彻底。比如：He harbours a wish to be a world championship. 这句话中的 harbour 如果按照 “港口” 来理解，那么这句话就废了。但是，智商正常的考生们都能猜出来 harbour 这里是一个动词的地位吧，通顺点的话至少得有一个 “has” 的意思吧。对，就是这样的，这种情况下，单词的意思跟着句子赋予它的意思走，如果背单词的时候真的只记得 “港口”，那么至少，让自己对它的理解放在 “可以翻译成港口，如果有必要，也可以是别的”，至少别把自己的 mind 限制在唯独那一个中文解释上。这里请注意，新地在悉尼研究了一些认知理论，说真的，其实背单词一次最好只记住一个意思，尽管很多词在不同语境有多个解释，而且会一起在英汉字典里写在那个词条边上手牵手一排出现，但是人脑真的记不住，overload，反而培养厌恶情绪。所以呀，一次一个，开心就好。

**克服障碍（2）**：单词都认识，句子看不懂。每个篇章有 5 个以上的长句子看不懂。

别纠结为什么我说 5 个以上，此题的目标是 100+，现在留学大军的战斗力各个 V5，没有 100 出门都不好意思和人打招呼。好的，那么问题就来了。具体一点，怎么看不懂了？哪一部分看不懂？什么样的句子经常看不懂？一般来说，短句子都没有问题，像 I love you 这个级别的，还有，那些只说了一件事情的句子一般也没有问题，比如，还是举 TPO1 passage 03 的栗子，这句 It ranges from sea level in the Polar Regions to 4,500 meters in the dry subtropics and 3,500-4,500 meters in the moist tropics. 这句也很容易理解，讲的是 “它有海平面那么高，在极地的话；它有 4,500 米那么高，在干燥的亚热带的话；它有 3,500-4,500 米，在湿润的热带的话。” 这句话就讲了一个事情，那就是 “在不同地区它的高度各有不同” 这么看来，真正看不懂的是那些逻辑不止一层意思的句子，人们亲 (tao) 切 (yan) 地将它们称作 “复杂句”，或者 “长难句”。这就好办了，你以为我会说再去学语法吗？不是哦，该学的语法知识早在大家初高中都教了，尽管该忘的也忘了，但是这么多年了，是该时候换一种新方式了。新地推荐是：把长句子分尸。这么说太阴森恐怖，我们这么想吧，就像庖丁解牛，分解托福句子。 下面这个逻辑很好理解，既然你能看懂短句子，那么练成把所有长句子都分解成短句子的能力，你就所向无敌啦。怎么分解呢？现场解剖一个： Wind velocity also increases with altitude and may cause serious stress for trees, as is made evident by the deformed shapes at high altitudes. 这个句子典型就是 highlight 会出现的那种长句。我们解剖句子的时候，下刀子的地方怎么判断出来，判断的标准是 “一个完整的意思”，也就是说明白了 “Somebody does sth”, 下面新地用 “/” 这个符号来表示，句子可以被切割为：

Wind velocity also increases with altitude / and may cause serious stress for trees, / as is made evident by the deformed shapes at high altitudes.

这下割成了三段，每一段来看看。

Wind velocity also increases with altitude 风速随着海波的升高而增加

and may cause serious stress for trees, 这个问题会造成对树木的压力

as is made evident by the deformed shapes at high altitudes. 高海拔的树变形了，足够说明这个问题了。

是不是感觉好了很多？就这么练！

句子切割的能力其实完全可以自己 DIY 练习，TPO 文章的全文翻译网上下载就好，自己阅读的时候找 highlight 题的句子玩解剖，或者其他文中的长句子也可以，回头再拿网上的翻译核对一下。长句阅读成功的评判标准就是：不用做到翻译信达雅，又不是当翻译员的，能理解，能用大白话说话来，人类能听得懂就好。

**克服障碍（3）：**句子几乎都看懂，但是句间关系理不清楚的，只能靠毛估的。

对于这个问题，需要给自己安装一个小插件，在阅读完一句话的时候，需要问自己一句 “作者为什么写这句话”。也就是，这句话的作用。能有幸刊登在 TOEFL 考卷上的文章都是学术论文改写过来的精华之作，字字珠玑，一般来讲没什么废话，那么每一句话必有自己的作用。栗子：

The most striking characteristic of the plants of the alpine zone is their low growth form. This enables them to avoid the worst rigors of high winds and permits them to make use of the higher temperatures immediately adjacent to the ground surface. In an area where low temperatures are limiting to life, the importance of the additional heat near the surface is crucial. The low growth form can also permit the plants to take advantage of the insulation provided by a winter snow cover. In the equatorial mountains the low growth form is less prevalent.

（高山植物最突出的特点是其低矮的生长形态。这种特点使他们能够避开大风最强势的势头，并且有助于他们利用紧邻地面相对较高的温度。在这样一个低温限制生命的地区，地表提供的额外温度是至关重要的。低矮的生长形态也可以帮助植物充分利用冬季积雪所提供的保温环境。在赤道区的山脉上低矮的生长形态并不常见。）

这段话，加上对每个句子作用的判断，就变成了下面这个版本：

The most striking characteristic of the plants of the alpine zone is their low growth form. （第一句讲的是一个现象：A 地区的植物矮）This enables them to avoid the worst rigors of high winds and permits them to make use of the higher temperatures immediately adjacent to the ground surface.（第二句讲的是现象的理由：矮是因为可以避风和取暖） In an area where low temperatures are limiting to life, the importance of the additional heat near the surface is crucial.（第三句讲的是理由的解释：取暖很重要） The low growth form can also permit the plants to take advantage of the insulation provided by a winter snow cover.（第四句随便插嘴了一句矮的又一理由：雪天保暖） In the equatorial mountains the low growth form is less prevalent.（第五句话讲的是对比：赤道上的植物可不矮。）

理清了这些关系，瞬间就明白了，这一段话讲的就是：“A 地区的植物矮，矮的有理由。” 是不是超级清楚。当然，有几篇文章的一些段子是比这复杂的，但是用这种去识别句子作用的方法，绝对可以化繁为简。如果直接上英文还是头晕，可以先拿上一个障碍克服中的翻译部分练练手，找找感觉。

**克服障碍（4）和（5）**：段落间关系只能靠毛估的；词句没问题，但是整个文章看完觉得作者吃饱了撑着写得很凌乱。

这两个障碍放在一起扫除。其实照上述的那个练习方式，已经可以把每一段的意思用一句话来说出了。接下来，就是根据文章的主题，拼装起来。画一个文章内容的树状图，新地把它叫做 Mind map. 还是拿 TPO1-Passage 03 的栗子：每一段的大意总结可以归纳成一条色彩不同的词条，全部链接起来，就是一个 mind map。

![](https://pic2.zhimg.com/50/a398456347dbf2b2e76f937916adecfd_720w.jpg?source=1940ef5c)

这是一个非常重要的阅读能力，把阅读到的信息整合起来。这些能力都是百加托福必备的，平时要做好准备，有了这些装备以后，实战其实还是需要魔法加成的。那就是，技巧。

首先，在实战 TOEFL 考试当中，对阅读速度的要求我们来计算一下： 每篇 passage 大约 700 words，还得做题，每篇 passage 后面的题目和选项的字数加起来大约 600 words。60 分钟 3 篇 passage，也就是说 60 分钟的时间需要阅读的信息量是 3900 words. 那么，一分钟需要阅读 65 个 words. 除非速度够快，否则根本来不及一个词一个词地看。

**于是问题就来了，怎么处理信息才够快？**

还记得刚才我们练习的 “判断作用” 这个能力吗？这个能力的用武之地就在于，当你看了一个句子的时候，判断：是细细读它，还是：先粗粗读它记住它的作用等会题目问到了再回来细细读它。就比如刚才我们看过的那个句子：“It ranges from sea level in the Polar Regions to 4,500 meters in the dry subtropics and 3,500-4,500 meters in the moist tropics. ” 这句话看完只需要 2 秒，我们完全可以不用管里面的海拔多少米，我们只管记住这句话的作用是说明了 “不同地区的不同高度” 这个作用就好。如果题目后来问到了在 dry subtropics 的高度是神马，我们再回来这里瞄一眼数字就好了。

于是乎，我们的阅读变得潇洒了很多。而且 TOEFL iBT 机考用的界面非常友好，左右屏幕对应题目和文章，不用像雅思烤鸭们那样翻着纸页找，定位就方便多了。

对了，刚才说的我最近在写的那个阅读指南，内容大致是这个流畅走得，大家给点反馈，有神马需要补充的可以留言说哦，这样写起来也有动力。见下图：

![](https://pic3.zhimg.com/50/1208f70050732826d52627c15ae4a371_720w.jpg?source=1940ef5c)

![](https://pica.zhimg.com/50/e1ba12cdd6f3bd6bac4ed338e6b03558_720w.jpg?source=1940ef5c)

![](https://pic1.zhimg.com/50/328ef307a3d7f9a575d2721ade201edf_720w.jpg?source=1940ef5c)

![](https://pic2.zhimg.com/50/v2-a1cba00ed31e332ba51d27d94e481078_720w.jpg?source=1940ef5c)

文本太长了，就不一一贴出来了。给个参考就好。

\------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------  

**（4）口语，**

学习资料：还是 OG, TPO1-15，还有下面贴出的备考资料。

使用方法：

OG，还是网上下载到的那个电子版的。看完下面这个章节，你就妥妥地了解了 TOEFL 的 speaking section 的长相和武功招式了。

![](https://pic4.zhimg.com/50/431e559388a54ee2c9de1ba8d9692d64_720w.jpg?source=1940ef5c)

总结一下，一共有六道 questions，而且没有加试，真是一个靠谱的 section 对吧。Q1Q2 是独立口语题，Q3Q4Q5Q6 是综合口语题。这两部分题目的备考虽然看起来都是练嘴皮子，但是考察能力不仅如此，而且大径相庭的，所以，要分开用不同的法子备考。

独立口语 Q1Q2 的颜值还是可以的，举些栗子：

说说你看过的一本书（TPO1-Q1Talk about a book you have read that was important to you for some reason. Explain why the book was important to you. Give specific details and examples to explain your answer.），

描述一个你经常去的地方（TPO2-Q1 Choose a place you go to often that is important to you and explain why it is important.），

你觉得钱多应该任性还是应该干实事儿（TPO16-Q2 Some people who unexpectedly receive a large amount of money spend it on practical things, while others spend it for pleasure only. Which do you think is better and why?）.

总之，就是给出一个问题，让考生娓娓道来，由于出题方 ETS 只给了 45 秒，而且不少同学还克制不住自己眼睁睁看屏幕上一秒一秒地倒计时的恐惧，基本只能紧张得匆匆道来，更甚者吓得语无伦次。好吧，怎么办捏。第一步，接受现实，“… 就是开不了口让他知道….”（杰伦某首歌的调调），没什么大不了的，这不是还有第二步么。第二步，要想得开，毕竟这种现象是肤浅的纸老虎，它的下面暗藏的是什么本质问题呢。请对号入座：

1.  这种题目我中文都不会答，
2.  我早该背几篇万能模板的，但是我懒，T\_T
3.  模板我真背了，但真想不起来了
4.  天哪我想说的词儿怎么都不会说…. 第三步，接受治疗。

那我们就从对号入座那里开始。（Sindy 暂时就只想到了这 4 种考生大脑 down 机时候的状态，有遇到更多状态的欢迎以后留言补充。）我们先来看看这四种怎么治：

**（1）对于中文都不会回答的考生**

只能说，这和英语真的没有半毛钱关系。请回炉重造。也就是，先用母语至少把思想回路构建起来。要不然真的没得玩了。这里有两个层次：第一层是能够表达自己最直觉的意思，尽管大多数时候会很土但是自己往往发现不了土在哪里。第二层相对高级一点，是能够用老美的思维方式想出你要说的内容。举个栗子：如果口语题问的是 “描述你认识的一个人”，第一层次的回答往往是这样的：“我要讲的这个人是我同班一男生，他团结同学，热于助人，品学兼优。” 而第二层的回答是这样的：” 我要讲的这个人是我同班一男生。我认识他的时候是在我念高中的时候。他是个高个儿，那时候就有差不多 180cm 了。整个一典型亚洲美少年。我还记得当时常见到他和别班的帅哥打球。说真的，他挺帅的，尤其是打球的时候。我还挺喜欢他和我说嗨时候的感觉的。”

请问第一层次到底哪里不妥了？很明显，不容易转成英语呀。这么说很顺口很爽没错，但是这酸爽的感觉会让你在想要说英文口语的时候不停地内心问 “团结同学好难讲，品学兼优怎么翻译呀，太难了吧，逆天了啊。” 没错，美剧里面从来没有出现过这些词啊。再看第二层次，是不是感觉清新了很多，瞬间流川枫了呀。而且超级好翻译，里面没有任何一个词是过了六级的你不会讲的吧？句句秒回的感觉就是那么自信，awesome！那么好了，我们来分析一下，为了达到第二层的口语内容，我们需要怎么练习：

首先，我们可以看一点翻译过来的美国电视剧，知道 Sindy 在暗示什么了吗？没错，**翻译腔**。如果真的对于老美说话的方式没有感觉，听听翻译腔还是会给你一点思路的。当你听到 “哦，我的上帝呀，看这漂亮的沙滩，阳光还有你的香肠。这真的是一个棒极了的下午，我真的开心得不能再开心了。真希望每天都能像今天一样。” ，是不是有感觉了？如果下次你在想这问题该怎么回答的时候，可以在心里养成这样构思的习惯。其实上面那段是 Sindy 和朋友去 Coogee 沙滩时候一 Aussie 哥们有感而发的。句句简单，但是句句地道，脑补了以后，翻译腔浑然天成。应该不难想到当时说的是 Oh my God. Look at the beautiful beach, the sunshine, and your sausages! It’s such a fantastic afternoon. I couldn’t be better. Just wish my everyday could be like this. 好吧，那天出门的时候的确带了几根烤肠。不要在意这些，重点是，考生如果这样思考，回答起来就不难了。就用这个方法构思内容。

另外，其实大家也发现了，要想英语有话讲，语言内容构思上最好具体点，再具体点。总之，就是一个字：**具象**。（Sindy 数死早，请海涵）。

就像上面说的那个同班男生，别光说人家身上的抽象的品德，至少说说人家的身高，长相，于是乎，活灵活现的一个流川枫就出来了。当然，也不用从头发，额头，睫毛，眼睛，鼻子，人中，嘴巴，下巴，双下巴统统说一遍，尽管 Sindy 见过课上讲完了人物的形容词就开始从头到脚扫描地讲的，以考官的智商，一定听得出这不是人话。

所以，点到几个细节就好。其实，中西的语言差异中最大的特点源自文化差异，天朝文化讲究的是意境，西方文化讲究的是实物。中国菜有一道叫做蚂蚁上树，听着就有韵味，英文菜单上写的却是 vermicelli with spicy minced pork，说的都是大实话，中国大厨当场就不爽了 。好了，不扯远的，回来继续说。

**（2）没背模板** **&（3）背了模板但是想不起来**

这下解决了大脑中内容构思的问题，回到刚讲对号入座的第二点和第三点都是讲模板的，这两点一起讲吧。

请问，模板要背吗？为了回答这个问题，我们去找一个模板来看看先，独立口语题目的模板基本长相就是这个样子。

![](https://pica.zhimg.com/50/cb821b5866e1878cf9d9dd72d912e0c7_720w.jpg?source=1940ef5c)

如果你连 personally，reason，这些词都造不成没有语法错误的句子，那么模板还是有用的，至少从蹦单词状态到了有话讲的状态了。但是楼主都过了 CET6 了，这个模板就发挥不出效用了。毕竟，模板的划线填空区域和写了字给背诵的区域，非常多考生是把握不好衔接和流畅性一致的。那么怎么办办捏？

说实话，先问问自己，为什么要模板？我还真问过这个问题，很多学生回答：因为模板写得好。那么，又请问，“好” 的标准是什么？学生回答：模板是一个完整的事儿呀，讲得清清楚楚的。OK，原来这就是大多数考生拥抱模板的理由。但是，大哥呀，你知不知道其实 OG 里面考官写得很清楚了评分标准呀！下图是最高分数段位的标准。

![](https://picx.zhimg.com/50/24e55084fdbfb650ae064809f55f7aa2_720w.jpg?source=1940ef5c)

如果仔细去看，你就会发现，即使题目问的是 “Choose a place you go to often that is important to you and explain why it is important” 考官的真正的目的也不是挖掘你真常去的什么破地儿，他又不是狗仔队，才不关心你的隐私，他甚至也不关心你回答得是不是一个完整的故事。他只关心：**你是不是关于这题说人话了，你说了什么话，用了哪些个词儿，他能不能听懂。**

OG 里面，就是上面截图给大家的那个托福指南第三版，在第七章就是一套 TPO2 模考，问的就是 place 这个题目，而且后面带有配套光碟里面高分学生的回答，听上去是一个俄罗斯姑娘的录音。（不知道知乎可不可以上传录音，如果可以记得教我，我下次传上来。）解析的部分有 rater’s comment，也就是评分官对考生为什么拿高分的理由分析。大家可以去听听那个姑娘回答得如何，内容是这样的：I would like to go, …hmm, I often go to France because I met a friend of mine..ah..two years ago, and she invited me already several times. They’ve been there already for several times. And I always have been fascinated by French history and started to read in French, ah, books, _although_ in the Russian, _but_ not in French, ah, since I was 12. Ah… and I’ve been already in the south so right now I’m going to the north of the country. And I would like to try their famous yogurt, cheese, wine, and just to see the/ 她最后几句话没来得及说完，时间到了，录音停止。这段录音我会操作以后上传，记得提醒我，如果着急的朋友也可以自己去网上找找 OG Track30。当然，语音语调也是一部分。关于语音语调另外找时间再讲吧。one thing at a time.

下面是针对这个俄罗斯姑娘的回答，考官给出的评论：

**Track 30**

Rater’s comments

The speaker continues speaking throughout the entire 45 seconds. She speaks clearly using a variety of vocabulary and a wide range of grammar. Her reasons are well-developed. She uses specific details about why France is an important place for her. Instead of just saying “I’m interested in French culture because it is interesting,” she elaborates by talking about her friend, her interest in French history and culture from a young age, and the food. There is a logical progression of ideas that makes the response easy to understand.

看吧，考官关心的是是否流利说了 45 秒，不要在意最后一秒有没有说完。考官关心的是你用了哪些表达，说白了就是拓展你的话题，不必局限于模板。考生真的没有必要和题目中 “explain why it is important” 这几个字死磕，人家考官根本就不关心，俄罗斯小姑娘也没赤裸裸说 important，倒是说了一堆具象的东西，和你谈法国的酸奶，奶酪，葡萄酒。听起来就是那么带感。你也可以的。

所以，你的目标就是：拓（che）展（dan），而且要围绕着题目扯淡。不会扯淡是吗？？那下面这个趴趴英语的 0 元托福课正适合你，采用独立口语思维拓展法，15 秒内构思高分答案。更有针对阅读的长难句破解法，化难为简有效阅读。针对听力抓不住重点，传授预判定位，针对写作总是低分，先来搞定重点题型。点击下方链接，4 步助力托福全科提升，高效备考，现在就来轻松搞定托福吧。  

  
下面我们来练习扯一个：

TPO1-Q1

Talk about a book you have read that was important to you for some reason. Explain why the book was important to you. Give specific details and examples to explain your answer.

话题是 book，足矣。

有看过的书吗？纯中文的最好别说了，更别说中国古代的，除非你真的特别在行，免得大脑转译速度跟不上，考官也听不懂，要是讲三国演义那真的够呛，满口 somebody killed somebody，一股浓重的三国杀味儿，还讲不清楚。拜托，人家只让你讲 45 秒，注意单位是秒，这一分钟都不到的时间能讲几句话？一句话如果讲 7 秒，那么 45 秒充其量能讲六句半。别给自己添堵了，成吗？挑个简单的，就哈利波特吧，不会拼写？没关系，口语考官才不管你会不会拼写呢，那是写作 section 的事儿。选哈利波特的原因很简单，就算没看过书至少看过电影吧，如果电影也没看过，至少听说过吧。好的，开始说话。

第一句：I want to talk about Harry Potter, the book. 然后开始扯，想法子和自己拉关系，比如你几年级的时候开始知道这本书的。

I first got to know the book when I was in my high school. 或者你大胆说我就是没看过，不过我有些朋友看过，而且哈利波特不止一本，它是一个系列的 7 本奇幻小说。

Well, actually I’ve never read the book myself. _But_ some of my friends have. The Harry Potter is not just a book, technically, Harry Potter is a series of seven fantasy novels . 还可以讲，我知道有这书关于哈利和他的小伙伴在魔法世界冒险的。在全球超级火。后来还被拍成了电影，也超级火。

The books are about Harry’s adventures, with his friends, in the magic world. And the books are super popular around the globe, and have been made into film series by now, which are also super popular. 如果知道得再多一点就加一个这书的作者是 J.K. Rowling. 人家靠这书赚了好多钱。

The Harry Potter series are written by J.K. Rowling, and she earned a lot of money from the books. 还能扯吗？不能的话，加上自己对这书的看法：我很喜欢这故事，超级精彩。

I’m really into the magic story. It’s fantastic. 搞定。以后养成习惯以后脑速会快很多。这么舒爽的内容一秒变口语。

这里 Sindy 没有用任何有难度的词，用意是为了让大家相信，你的口语完全可以有自信。当然，做一些词汇，短语，词组等地道表达方式的积累和学习是好事儿，但是这不意味着你靠自己原有的水平就一定开不了口，说不成段子。有好多考生总觉得要说出高难度的词汇才有面子，其实不然，真正好的英文表达的判定标准是 “表述精准，用词应景”，接地气才是王道。

关于话题拓展，最好的方式就是从多方面没话找话，时间，地点，感觉，长相，起因，天气，关系，你的所见所闻等等的多个方面。比如找时间上自己第一次什么时候接触，或者平时一般怎么接触，地理位置上套近乎，说说和自己的关系，讲讲自己的感受，多用具象的描述。用这个方式练，关键是真的每天都练。

**（4）口语想说的词儿不会说。**

在治疗了上述 3 个症状以后，其实有些词儿还是需要有平时的积累的。但是重点还是要能够以句子为单位地说出。

考生们可以自己整理其他不同的话题：下面也贴出了不同的话题可以去哪里找到资源。  

—— 地点篇：

[Lonely Planet travel destinations](http://www.lonelyplanet.com/destinations)

—— 人物篇：

[People.com : Celebrity News, Celebrity Photos, Exclusives and Star Style](http://www.people.com/people)

—— 游戏篇：

[The Online Guide to Traditional Games](http://www.tradgames.org.uk/)

—— 电影篇：

[http://www.imdb.com/](http://www.imdb.com/)

—— 图书篇:

[http://www.amazon.com/](http://www.amazon.com/)

对你没有看错，就是亚马逊，Sindy 不是来做广告的，是让你看亚马逊上的平理论的，见下图，这是饥饿游戏页面，注意头条评论：

![](https://pica.zhimg.com/50/fb55702d7580f6832d8c067e09e5f925_720w.jpg?source=1940ef5c)

![](https://picx.zhimg.com/50/1f9290027ec35925211897e637850bf2_720w.jpg?source=1940ef5c)

你要是备考用这个资料，绝对完爆其他考生 N 条街。当然，不是叫你原模原样背下来啦，而是学学他们怎么用词怎么造句的。以后咱自己扯淡要扯成这样才有意义。什么？看不懂，个别几个词自己查词典去。

—— 音乐篇：

[http://www.unsignedhandweb.com/](http://www.unsignedhandweb.com/)

—— 运动篇：

[http://www.justlanded.com/](http://www.justlanded.com/)

另外，平时练习口语的时候，一定要**计时 + 录音**。一是为了让自己熟悉说话 45 秒的长度感觉和节奏，二是让自己听听口音和原版哪里差距比较大，方便改过来。

对了，说到英语的发音，understandable 就可以了，不用太挑剔，不用逼着自己练成纽约音或伦敦腔的。

当然原来口音就好听的是一个加分项，但是只有 3 个月的备考时间，还是把 priority 放在其他更重要的地方，**内容**。如果发音做不到 understandable，那是一定要做纠正的。

模仿语音语调，口型自己练习的时候夸张一点没关系。练到什么标准算是成功了？检验途径有不少，找老外朋友听听，把自己的录音和原版对比，我的学生都被要求口语录音发给我来帮他们找茬。Sindy 这里推荐一个 DIY 方便实用的，Siri。如果你说的话 Siri 能秒懂，那应该差不到哪里去。其实 Siri 还是蛮闷骚的。Sindy 和 Siri 的聊天记录见下图：

![](https://pic4.zhimg.com/50/b36c4c05cac1e9bebd83afbdef2de9da_720w.jpg?source=1940ef5c)

![](https://picx.zhimg.com/50/af62466557dc0818141a196a9ff69295_720w.jpg?source=1940ef5c)

![](https://picx.zhimg.com/50/b98ab1ddda2b50b14c4a647b3e399154_720w.jpg?source=1940ef5c)

![](https://pic2.zhimg.com/50/95925162ec06b4c2f2af604d78c79488_720w.jpg?source=1940ef5c)

咳咳，其实 Sindy 没有那么寂寞。只是一个栗子而已。不要在意这些细节。

另外，Sindy 告诉一个大秘密，别听人家讲口语最难云云的，口语回答是最最简单的，理由？因为你可以只用你会的词呀，它不像是阅读听力，人家出什么超级高难度的词你是没有掌控力的。口语可以，随！便！讲！当然是独立口语题。

最后，口语考试实战的时候，走进考场切记，要保持盲目的自信。说话的时候尽可能别 murmur，，最好大声点。如果太小声录音效果不好会被邻座的噪音干扰，会影响考官对你口语的打分，而且只有给低了，因为他真听不清。能理解考官把耳机音量调到最大还是听不清的那种痛苦吗，而且相比之下，电脑本身随便发出点机械音就响到要死。口语平时录音的时候，大家可以体会到那种心情，这点 Sindy 说多了都是泪。。。。

今天果然脑洞开大了，写多了又。综合口语题明天继续吧，今天我先休息会儿。

\------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

综合口语继续：

说到综合口语，这种大融合的出招方式不得不算是美国花式作死的典范，犀利又全面地挑逗到了考生口语的痛点。做个最直接的对比，如果在独立口语的 Q1Q2 中，考试可以很爽地随心所欲侃大山，那么综合口语就是小心翼翼的亦步亦趋。Q3456 的长相大家应该都是见过了的，小白们请参考 OG 第四章口语扫盲，Sindy 这里就不废话了。总结起来，若按相貌来分，Q3Q4：阅读文章 + 听力段子 + 口语 60 秒计时录音；Q5Q6 听力段子 + 口语 60 秒计时录音。若是按照内容来看，Q3Q5 是校园倒霉蛋大集合，尤其是 Q5 的主角个个是糗百楼主。Q4Q6 是教师正规军，逼格高，领域广，惊艳你没商量。如果看客你是临时抱佛脚的，那就按照题目的相貌分类备考，背背模板，我不拦着你。但是这里我们讲的是 3 个月以后胸有成竹地去机房虐托福，那么必须按照内容来。这一刻你执着语言质量，下一刻你就能在美帝的讲台 impress 听众。好了，鸡汤就先喝到这里。

**最后预祝所有备考托福的小白们都能成功分手**