---
doc_type: hypothesis-highlights
url: 'https://www.v2ex.com/t/826949'
---

# M1 MBP 电池寿命 - 究竟信谁? - V2EX

## Metadata
- Author: [v2ex.com]()
- Title: M1 MBP 电池寿命 - 究竟信谁? - V2EX
- Reference: https://www.v2ex.com/t/826949

## Page Notes
## Highlights
- 恰好帮一个朋友写过查看电池寿命的软件 https://apps.apple.com/us/app/battery-station/id1498721559 我这里从代码获取到的数据分析一下原理 电池有一个设计容量，比如 8000mah, 但实际生产电池的时候，电池容量一定是大于 8000mah 的，比如 8200mah, 这个是峰值容量，这个容量是真实的，可以充电达到这个值，而且这个值可以通过 API 拿到，比如我计算的时候就使用的这个值. 对苹果而言，只要峰值容量能达到 8000mah, 就是没有耗损，充电能达到 8000mah 就是充满，这完全符合设计标准 然而，如果电池真的峰值就是 8000mah 了，苹果计算得出 (实际 / 设计),8000/8000=100% 无损耗，我的软件计算 (实际 / 出厂校准的峰值) 8000/8200=97.56%, 有损耗 其实不用太在意，多出来的 200mah 本来就是设计之外白给的 我使用 8200mah 来计算，一来是为了准确知道电池的状况，二来也是为了和系统的区分一下 — [Updated on 2022-10-14](https://hyp.is/N2ZhYkuREe2ffvvEKA0VAA/www.v2ex.com/t/826949) — Group: #inbox




