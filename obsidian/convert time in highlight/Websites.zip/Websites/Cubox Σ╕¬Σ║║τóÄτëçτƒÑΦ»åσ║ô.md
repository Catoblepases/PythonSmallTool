---
doc_type: hypothesis-highlights
url: 'https://cubox.pro/my/card?id=ff80808182d413ff0182efeeead832a0'
date created: 2023-08-11
date modified: 2023-08-13
---

# Cubox 个人碎片知识库

## Metadata
- Author: [cubox.pro]()
- Title: Cubox 个人碎片知识库
- Reference: https://cubox.pro/my/card?id=ff80808182d413ff0182efeeead832a0

## Page Notes
## Highlights
- 一早去工作室锻炼，读 T.S. 艾略特《现代教育与古典文学》，他说 “广泛阅读之所以有价值，那是因为在受到一个接着一个的强大个性的感动过程中，我们就会变得不再受任何一个或任何少数强大个性的统治。” — [Updated on 2023-08-11](https://hyp.is/Qux4sDhhEe6InWeSvS55-g/cubox.pro/my/card?id=ff80808182d413ff0182efeeead832a0) — Group: #inbox

