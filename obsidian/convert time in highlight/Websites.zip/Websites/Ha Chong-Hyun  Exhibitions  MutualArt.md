---
doc_type: hypothesis-highlights
url: 'https://www.alminerech.com/exhibitions/'
---

# Ha Chong-Hyun | Exhibitions | MutualArt

## Metadata
- Author: [alminerech.com]()
- Title: Ha Chong-Hyun | Exhibitions | MutualArt
- Reference: https://www.alminerech.com/exhibitions/

## Page Notes
## Highlights
- Therefore, when absolutely necessary to mention the name of such a person, it is an etiquette to repeat each syllable in the given name, followed by the word “자” for character, thereby relaying the name as a linguistic notion rather than as a singular proper noun. — [Updated on 2023-02-25](https://hyp.is/bYyHILUjEe2L0jdd38kY0g/www.alminerech.com/exhibitions/) — Group: #inbox




