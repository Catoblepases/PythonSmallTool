---
doc_type: hypothesis-highlights
url: 'https://m.douban.com/note/791597099/'
---

# 【翻译】朱迪斯·巴特勒《“性别麻烦”（Gender Trouble）三十年后的反思：回应贺萧（Hershatter）、卢斯（Loos）以及帕特尔（Patel）》 - 日记

## Metadata
- Author: [m.douban.com]()
- Title: 【翻译】朱迪斯·巴特勒《“性别麻烦”（Gender Trouble）三十年后的反思：回应贺萧（Hershatter）、卢斯（Loos）以及帕特尔（Patel）》 - 日记
- Reference: https://m.douban.com/note/791597099/
- Category: #article

## Page Notes
## Highlights
- 我很荣幸，或许说非常惊讶地读到这些全面详尽的专门讨论亚洲研究中对《性别麻烦》之挪用的学术论文。“挪用（appropriation）”有时是一种很有问题的活动，例如，为了达到市场流通、利润或增加人力资本之目的而对少数族群（如原住民）的艺术作品和风格进行文化挪用。但当《性别麻烦》这样的文本进入全球书籍市场时，另一种挪用成为了可能。这本书很快被接纳并又被拒绝，这表明了翻译的局限性亦或标志着对文化帝国主义的抵抗。 — [Updated on 2022-09-09 13:06:52](https://hyp.is/gfzKcjAvEe2Ojod067e9_w/m.douban.com/note/791597099/) — Group: #inbox

- 实际上，在过去的十年里，这本书与其说对左派而言成为了文化帝国主义的标志，不如说更被福音右派（evangelical Right）和所有将性别视为源自美国沿海精英的“意识形态”的人视为文化帝国主义的标志。 — [Updated on 2022-09-09 13:07:25](https://hyp.is/ljnpojAvEe2gCu89jPOMaQ/m.douban.com/note/791597099/) — Group: #inbox

- 但右翼的批评集中在这样一个概念上，即认为性别（gender）作为一个概念促进了对视异性恋为正统的霸权家庭（heteronormative family）的破坏（destruction）、父权制的终结以及淫秽式的自由（如繁殖自由和性的再指派（sex reassignment）），而所有这些都会如教宗方济各（Pope Francis）所言——导致“文明的毁灭”。 — [Updated on 2022-09-09 13:07:41](https://hyp.is/n6KB3jAvEe2fnaMO9NkPuQ/m.douban.com/note/791597099/) — Group: #inbox

- 在罗马尼亚，现行法律禁止性别研究，而在波兰，所有跨性/别者（trans people）都必须遵循现行法律重新采用其出生时被指派的生物性别（sex assigned to them at birth）。 — [Updated on 2022-09-09 13:09:01](https://hyp.is/zvdARjAvEe2N-vPO31y52g/m.douban.com/note/791597099/) — Group: #inbox

- 在这类右翼批判中一个一致的主题是，性别（gender），被视为一种建构，要么引起家庭和亲属形式之文化变异性（cultural variability）的论述，要么使得藐视和亵渎自然法（natural law）的自由（堕胎、跨性/别者权益、同性恋婚姻、保护女同性恋和男同性恋生命的反歧视法）之行使成为可能。在某些方面，对“性别意识形态（gender ideology）”的攻击是对人类学和历史、文化理论和文化批判的攻击，是在暗示性（sex）应是不变的和单义的，性欲应是由视异性恋为正统的霸权家庭（heteronormative family）所框定的异性恋，而文化和历史之变化则是导致我们偏离《圣经》或真科学的假象或错误。在某种程度上，对“性别意识形态”的攻击——一系列幻想所产生的压缩效应、一种简略的假想建构——既是反对作为方法论的社会建构，也是反对那些在人文学科和社会科学领域中这种思想广泛流传并占据主导地位的大学。 — [Updated on 2022-09-09 13:09:58](https://hyp.is/8UPxHDAvEe2UmLufBkSuTg/m.douban.com/note/791597099/) — Group: #inbox

- 我自己的观点最终是，文本并不需要逐个论点、逐章地理解。读者可以或应该从文本中获取某些东西，从而处理这些东西并进行相关行动。换句话说，它应该被创造性地撕开并被积极地占用（appropriated）。 — [Updated on 2022-09-09 13:14:03](https://hyp.is/gvTfkDAwEe2foOvcy3QrvA/m.douban.com/note/791597099/) — Group: #inbox




